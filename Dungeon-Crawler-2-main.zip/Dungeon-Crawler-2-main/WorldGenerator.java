import java.util.ArrayList;
import java.util.Arrays;
/**
  *this class handles the world generation
  */
public class WorldGenerator {

    // first room
    private static ArrayList<String> gridOne = new ArrayList<String> (Arrays.asList(
                "##################                ######################    ",
                "##        i     ##                ##      i           ##    ",
                "##  @           ###########       ##        *         ##    ",
                "##                       ##       ##                  ##    ",
                "##              #######  ##       ##################  ##    ",
                "##        M     ##   ##  ##                       ##  ##    ",
                "##################   ##  ##################       ##  ##    ",
                "                     ##                  ##       ##  ##    ",
                "                     ##   *  i           ##       ##  ##    ",
                "                     ##                  ##       ##  ##    ",
                "                     ##############  ######       ##  ##    ",
                "                                 ##  ##           ##  ##    ",
                "                                 ##  ##           ##  ##    ",
                "                       ############  ###############  ######",
                "                       ##                                 ##",
                "                       ##                                 ##",
                "    #####################                  *              ##",
                "    ##                                                    ##",
                "    ##  #################                                 ##",
                "    ##  ##             ##                                 ##",
                "    ##  ##             #################  ##################",
                "    ##  ##                            ##  ##                ",
                "    ##  ##                            ##  ##                ",
                "    ##  ##                       #######  #######           ",
                "    ##  ##                       ##            ##           ",
                "######  ####                     ##  i  *      ##           ",
                "##        ##                     ##            ##           ",
                "## i  *   ##                     ################           ",
                "##        ##                                                ",
                "############                                                "
                    ));

    // second room
    private static ArrayList<String> gridTwo = new ArrayList<String> (Arrays.asList(
                "########################################",
                "##                                    ##",
                "##  i                                 ##",
                "##                   *                ##",
                "##                                    ##",
                "##################################    ##",
                "                                ##    ##",
                "                                ##    ##",
                "                                ##    ##",
                "################                ##    ##",
                "##            ##                ##    ##",
                "##       M    ##                ##    ##",
                "##            ####################    ##",
                "##                                    ##",
                "##                                    ##",
                "##            ####################    ##",
                "##            ##                ##    ##",
                "##            ##                ##    ##",
                "################                ##    ##",
                "                                ##    ##",
                "##################################    ##",
                "##                                    ##",
                "##         *                          ##",
                "##                                    ##",
                "##                                    ##",
                "##                                    ##",
                "##  i                          *      ##",
                "##                                    ##",
                "########################################"
                    ));

    // third room
    private static ArrayList<String> gridThree = new ArrayList<String> (Arrays.asList(
                "#######################                               ",
                "##                   ##                               ",
                "##                   ####################             ",
                "##                                     ##             ",
                "##                                     ##             ",
                "##                   ###############   ##             ",
                "##                   ##           ##   ##             ",
                "##    i              ##           ##   ##             ",
                "#######################           ##   ##             ",
                "                                  ##   ##             ",
                "################################  ##   ##             ",
                "##                            ##  ##   ##   ##########",
                "##   i                        ##  ##   ##   ##   M  ##",
                "##                            ##  ##   ##   ##      ##",
                "##                            ######   #######      ##",
                "##                      *                           ##",
                "##                                                  ##",
                "##                                          ##########",
                "##                                          ##        ",
                "##                                          ##        ",
                "##   *                                    i ##        ",
                "##############################################        "
                    ));

    /**
      *creates a new world
      *
      *@param player the player character
      */
    public static World generate(Player player){

        ArrayList<Room> rooms = new ArrayList<Room>();

        // create the first room
        ArrayList<Portal> rOnePortals = new ArrayList<Portal>();
        Portal pOne = new Portal(4,4,"pOne","pTwo");
        rOnePortals.add(pOne);
        Room rOne = new Room(gridOne,rOnePortals, "rOne");
        rooms.add(rOne);

        // create the second room
        ArrayList<Portal> rTwoPortals = new ArrayList<Portal>();
        Portal pTwo = new Portal(12,4,"pTwo","pOne");
        Portal pThree = new Portal(25,4,"pThree","pFour");
        rTwoPortals.add(pTwo);
        rTwoPortals.add(pThree);
        Room rTwo = new Room(gridTwo,rTwoPortals, "rTwo");
        rooms.add(rTwo);

        // create the third room
        ArrayList<Portal> rThreePortals = new ArrayList<Portal>();
        Portal pFour = new Portal(4,4,"pFour","pThree");
        rThreePortals.add(pFour);
        Room rThree = new Room(gridThree,rThreePortals, "rThree");
        rooms.add(rThree);
        World world = new World(rooms, player);
        return world;
    }
}

