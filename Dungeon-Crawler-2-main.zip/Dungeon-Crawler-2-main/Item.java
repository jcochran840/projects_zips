// Item.java
/**
  *this class represents a single item, it could be an equippable
  *thing like weapon or ring, or something generic
*/
public class Item {
    // what sort of item it is
    private ItemType type;

    // the name of the item as shown to the user
    private String name;

    // how much it weighs (player can only carry so much)
    private int weight;

    // how much the item is worth for buying/selling
    private int value;

    // the item's strength - this differs based on the type
    // for a weapon, it's damage
    // for armor, it's protection
    private int strength;

    /**
      *item constructor
      *
      *@param type the item type
      *@param name the item name
      *@param weight the item weight
      *@param value the item value
      *@param strength the item strength, damage for a weapon, protection for armor
      */
    public Item(ItemType type, String name, int weight, int value, int strength) {
        this.type = type;
        this.name = name;
        this.weight = weight;
        this.value = value;
        this.strength = strength;
    }

    /**
      *gets an items weight
      *
      *@return the weight of an item
      */
    public int getWeight() {
        return weight;
    }

    /**
      *gets the items value
      *
      *@return the value of an item
      */
    public int getValue() {
        return value;
    }

    /**
      *gets the items strength
      *
      *@return the strength of an item
      */
    public int getStrength() {
        return strength;
    }

    /**
      *gets the items name
      *
      *@return the name of an item
      */
    public String getName() {
        return name;
    }

    /**
      *gets the items type
      *
      *@return the type of an item
      */
    public ItemType getType() {
        return type;
    }

    @Override
	/**
	  *translates the object description into legeible character
	  */
    public String toString() {
        return name + " " + weight + " " + value + " " + strength;
    }
}

