// Main.java

import ansi_terminal.*;
/**
  *contains the main class for running the game
  */
public class Main {

    public static void main(String args[]) {
        // put termain in raw mode
        Terminal.rawMode();

        // clears terminal
        Terminal.clear();

        // make and run the Game
        Game game = new Game();
        game.mainMenu();

        // clears terminal
        Terminal.clear();

        // put terminal back into cooked mode
        Terminal.cookedMode();
    }
}

