// Room.java

import java.util.ArrayList;
import java.util.Arrays;
import ansi_terminal.*;

/**
  *provides code for the drawing of a room
  *also provides starting locations for the player, boxes, and enemies
  */
public class Room {
    // the grid holds the room geometry
    private ArrayList<String> grid;

    // the size of the room
    private int rows;
    private int cols;

    // entities within the room
    private ArrayList<Portal> portals;
    private ArrayList<Enemy> enemies;
    private ArrayList<Merchant> merchants;
    private ArrayList<Box> boxes;

    // name of the room
    private String name;

    /**
      *this initializes the room to one specific space
      */
    public Room() {

        portals = new ArrayList<>();

        // default room portal
        Portal pOne = new Portal(4,4,"pOne","pTwo");
        portals.add(pOne);

        // the actual room geometry
        // the i cells refer to where an item should be placed at
        // the M cells refer to where a merchant should be placed at
        // the * cells refer to where an enemy should be placed at
        grid  = new ArrayList<String> (Arrays.asList(
                    "##################                ######################    ",
                    "##          i   ##                ##      i           ##    ",
                    "##  @           ###########       ##        *         ##    ",
                    "##                       ##       ##                  ##    ",
                    "##              #######  ##       ##################  ##    ",
                    "##          M   ##   ##  ##                       ##  ##    ",
                    "##################   ##  ##################       ##  ##    ",
                    "                     ##                  ##       ##  ##    ",
                    "                     ##   *  i           ##       ##  ##    ",
                    "                     ##                  ##       ##  ##    ",
                    "                     ##############  ######       ##  ##    ",
                    "                                 ##  ##           ##  ##    ",
                    "                                 ##  ##           ##  ##    ",
                    "                       ############  ###############  ######",
                    "                       ##                                 ##",
                    "                       ##                                 ##",
                    "    #####################                  *              ##",
                    "    ##                                                    ##",
                    "    ##  #################                                 ##",
                    "    ##  ##             ##                                 ##",
                    "    ##  ##             #################  ##################",
                    "    ##  ##                            ##  ##                ",
                    "    ##  ##                            ##  ##                ",
                    "    ##  ##                       #######  #######           ",
                    "    ##  ##                       ##            ##           ",
                    "######  ####                     ##  i  *      ##           ",
                    "##        ##                     ##            ##           ",
                    "## i  *   ##                     ################           ",
                    "##        ##                                                ",
                    "############                                                "));

        // creates the enemies and boxes in the room
        createEnemies();
        createBoxes();

        // default room row and column size
        rows = grid.size();
        cols = grid.get(0).length();

        // default room name
        name = "rOne";
    }

    /**
      *constructor mainly used by WorldGenerator class
      *
      *@param grid ArrayList of strings used to build the map
      *@param portals and ArrayList of portals
      *@param name room name
      */
    public Room(ArrayList<String> grid, ArrayList<Portal> portals, String name) {

        // stores map data
        this.grid = grid;
        rows = grid.size();
        cols = grid.get(0).length();
        this.name = name;

        // creates enemies, boxes, portals, and merchants
        createBoxes();
        createEnemies();
        createMerchants();
        this.portals = portals;

    }

    /**
      *constructor used mainly when hydrating rooms from save files
      *
      *@param grid ArrayList of strings used to build the map
      *@param portals ArrayList of portals
      *@param boxes ArrayList of boxes
      *@param enemies ArrayList of enemies
      *@param merchants ArrayList of merchants
      *@param name room name
      */
    public Room(ArrayList<String> grid, ArrayList<Portal> portals, ArrayList<Box> boxes, ArrayList<Enemy> enemies, ArrayList<Merchant> merchants, String name) {

        // stores map data
        this.grid = grid;
        rows = grid.size();
        cols = grid.get(0).length();
        this.name = name;

        // stores enemies, boxes, merchants, and portals
        this.portals = portals;
        this.boxes = boxes;
        this.enemies = enemies;
        this.merchants = merchants;
    }

    /**
      *gets the players starting position
      *
      *@return the player's starting location in this room
      */
    public Position getPlayerStart() {

        // iterates on every position on the map for a player marker('@')
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                if (grid.get(row).charAt(col) == '@') {
                    return new Position(row, col);
                }
            }
        }

        // cannot find player starting position
        return null;
    }


    /**
      *creates a new set of enemies for this map
      */
    private void createEnemies () {
        enemies = new ArrayList<>();
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                if (grid.get(row).charAt(col) == '*') {
                    enemies.add(EnemyGenerator.generate(row, col));
                }
            }
        }
    }

    /**
     *creates a new set of item boxes for this map, this is here because it depends on
     *the room geometry for where the boxes make sense to be
     */
    private void createBoxes () {
        boxes = new ArrayList<>();
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                if (grid.get(row).charAt(col) == 'i') {
                    boxes.add(new Box(row, col, ItemGenerator.generate()));
                }
            }
        }
    }

    /**
      *creates a new set of merchants for this map
      */
    private void createMerchants () {
        merchants = new ArrayList<>();
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                if (grid.get(row).charAt(col) == 'M') {
                    merchants.add(MerchantGenerator.generate(row, col));
                }
            }
        }
    }

    /**
      *gets list of boxes from map
      *
      *@return a set of boxes from this map
      */
    public ArrayList<Box> getBoxes() {
        return boxes;
    }

    /**
      *gets a list of enemies from map
      *
      *@return a set of enemies from this map, similarly to the boxes above
      */
    public ArrayList<Enemy> getEnemies() {
        return enemies;
    }

    /**
      *gets a list of portals from map
      *
      *@return a set of portals from this room
      */
    public ArrayList<Portal> getPortals() {
        return portals;
    }

    /**
      *gets a list of mercahnts from map
      *
      *@return a set of merchants from this room
      */
    public ArrayList<Merchant> getMerchants() {
        return merchants;
    }

    /**
      *gets room name
      *
      *@return the room's name
      */
    public String getName() {
        return name;
    }

    /**
      *gets row size
      *
      *@return the row size of the room
      */
    public int getRows() {
        return rows;
    }

    /**
      *gets column size
      *
      *@return the column size of the room
      */
    public int getCols() {
        return cols;
    }

    /**
      *draws the map to the screen
      */
    public void draw() {
        Terminal.clear();

        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                char cell = grid.get(row).charAt(col);
                CustomTerminal.warpCursor(row, col);
                if (cell == '#') {
                    // a unicode block symbol
                    System.out.print('\u2588');
                } else {
                    // whatever else, just draw a blank (we DONT draw starting items from map)
                    System.out.print(' ');
                }
            }
            System.out.print("\n\r");
        }
    }

    /**
      *checks is movement is posible to a location
      *
      *@return a boolean if a given cell in the map is walkable or not
      */
    public boolean canGo(int row, int col) {
        return grid.get(row).charAt(col) != '#';
    }
}
