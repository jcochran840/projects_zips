// Entity.java
// this class represents one moveable, drawable thing in the game

import ansi_terminal.*;
/**
  *this class represents one moveable, drawable thing in the game
  */
public class Entity {
    // the location of the entity in space
    private Position position;

    // the character used to draw it
    private char display;

    // the color used for drawing
    private Color color;

    /**
      *Entity constructor
      *
      *@param row horizonatal position
      *@param col vertical position
      *@param display symbol that represents character on screen
      *@param color character color
      */
    public Entity(int row, int col, char display, Color color) {
        position = new Position(row, col);
        this.display = display;
        this.color = color;
    }

    /**
      *move the entity to a new location
      */
    public void setPosition(int row, int col) {
        position = new Position(row, col);
    }

    /**
      *get the position of this entity
      *
      *@return the position of entity
      */
    public Position getPosition() {
        return position;
    }

    /**
      *get the color of this entity
      *
      *@return the color
      */
    public Color getColor() {
        return color;
    }

    /**
      *gets the horizontal position
      *
      *@return row
      */
    public int getRow() {
        return position.getRow();
    }

    /**
      *gets vertical position
      *
      *@return col
      */
    public int getCol() {
        return position.getCol();
    }

    /**
      *sets the entity's row
      */
    public void setRow(int row){
        position.setRow(row);
    }

    /**
      *sets the entity's column
      */
    public void setCol(int col){
        position.setCol(col);
    }

    /**
      *translate the entity in space, unless it would hit a wall
      *
      *@param rowChange new horizontal position
      *@param colChange new vertical position
      *@param room the room the entity is in
      *
      *@return a booleann if the entity can move to the desires place
      */
    public boolean move(int rowChange, int colChange, Room room) {
        // find new position
        int newRow = position.getRow() + rowChange;
        int newCol = position.getCol() + colChange;

        if (room.canGo(newRow, newCol)) {
            // draw a space where it currently is
            CustomTerminal.warpCursor(position.getRow(), position.getCol());
            System.out.print(" ");

            // and then move it
            position = new Position(newRow, newCol);
            return true;
        } else {
            return false;
        }
    }

    /**
      *draw this entity to the screen
      */
    public void draw() {
        CustomTerminal.warpCursor(position.getRow(), position.getCol());
        Terminal.setForeground(color);
        System.out.print(display);
        Terminal.reset();
    }

    /**
      *draw this entity to the screen with a custom color
      */
    public void draw(Color selectedColor) {
        CustomTerminal.warpCursor(position.getRow(), position.getCol());
        Terminal.setForeground(selectedColor);
        System.out.print(display);
        Terminal.reset();       
    }
}

