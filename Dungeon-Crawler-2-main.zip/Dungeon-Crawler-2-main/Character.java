// Character.java
/**
  *this class store the information for the all characters in the game
 */
import java.util.ArrayList;
import ansi_terminal.*;

public abstract class Character extends Entity {
    // the characters health points
    private int hp;
    private Color hurtColor;
    private boolean alive;
    private static final double HURT_TIMING = 0.085;

/**
  *comstructor for the player character
  */
    public Character(int row, int col, char display, Color color, int hp) {
        super(row, col, display, color);
        hurtColor = ContrastColorReferenceTable.instance().getContrastColor(color);
        this.hp = hp;
        alive = true;
    }

/**
  *returns the pc health
  *
  *@return the pc's current health
  */
    // get the hp, damage, protection and name of character
    public int getHealth() {
        return hp;
    }

    public abstract int getDamage();
    public abstract int getProtection();
    public abstract String getName();

/**
  *constructor for an enemy
  */
    public Enemy isOnEnemy(int rowChange, int colChange, ArrayList<Enemy> enemies) {
        Position newPosition = new Position(getPosition().getRow() + rowChange, getPosition().getCol() + colChange);

        for (Enemy e: enemies) {
            if (e.getPosition().equals(newPosition)) {
                return e;
            }
        }
        return null;
    }

/**
  *constructor for a merchant
  */
    public Merchant isOnMerchant(int rowChange, int colChange, ArrayList<Merchant> merchants) {
        Position newPosition = new Position(getPosition().getRow() + rowChange, getPosition().getCol() + colChange);

        for (Merchant m: merchants) {
            if (m.getPosition().equals(newPosition)) {
                return m;
            }
        }
        return null;
    }

    /** 
      *checks the positions of the character and the specified player to see if they are equal
      *
      *@param rowChange
      *@param colChange
      *@param player
      *
      *@return a boolean if the two positions are equal
     */
    public boolean isOnPlayer(int rowChange, int colChange, Player player) {
        Position newPosition = new Position(getPosition().getRow() + rowChange, getPosition().getCol() + colChange);
        return (newPosition.equals(player.getPosition()));
    }

    /**
      *gets the hurt animation color
      *
      *@return the color of the hurt animation
      */
    public Color getHurtColor() {
        return hurtColor;
    }

    /**
      *checks is character is alive
      *
      *@return a boolean if the character is still alive
      */
    public boolean isAlive() {
        return alive;
    }

    /**
      *kills character
      */
    private void notAlive() {
        alive = false;
    }

    /** 
      *do damage to another player

      *@param other
      *@param room

      *@return a boolean if the player has died
      */
    private boolean dealDamage(Character other, Room room) {
        // this character does damage to the other character
        int damageDone = getDamage() - other.getProtection();

        // marks if the attack does more than half the character's current health
        boolean criticalDamage = false;


        // prevent negative damage
        if (damageDone < 0) {
            damageDone = 0;
        }

        if (damageDone > (int)(other.hp / 2)) {
            criticalDamage = true;
        }

        // actually damage them
        other.hp -= damageDone;

        // prevent negative hp
        if (other.hp < 0) {
            other.hp = 0;
        }

        for (int i = 1; i <= 6; i++) {
            other.draw();
            Terminal.pause(HURT_TIMING);
            other.draw(other.getHurtColor());
            Terminal.pause(HURT_TIMING);
        }


        Box boxThere = other.isOnBox(room);
        Portal portalThere = other.isOnPortal(room);
        CustomTerminal.warpCursor(5,5);
        if (other.hp > 0) {
            if (boxThere != null) {
                other.draw(Box.BOX_COLOR);
            } else if (portalThere != null) {
                other.draw(Portal.PORTAL_COLOR);
            } else {
                other.draw();
            }
        } else {
            if (boxThere != null) {
                boxThere.draw();
            } else if (portalThere != null) {
                portalThere.draw();
            } else {
                CustomTerminal.warpCursor(other.getPosition().getRow(), other.getPosition().getCol());
                System.out.print(" ");
            }
        }

        // reset colors from printing
        Terminal.reset();

        // prints results of battle
        CustomTerminal.warpCursor(room.getRows()+1, 0);
        if (criticalDamage) {
            Terminal.setForeground(Color.RED);
            System.out.print("BIG DAMAGE! ");
            Terminal.reset();
        }
        if (other.hp > 0) {
            System.out.print(getName() + " does " + damageDone + " damage to " + other.getName()
                    + ", leaving " + other.hp + " health.                   \n\r");
            return false;
        } else {
            System.out.print(getName() + " does " + damageDone + " damage to " + other.getName()
                    + ", killing them.                     \n\r");
            return true;
        }
    }

    /**
      *checks if the character is on a box
      *
      *@param room the room that the characters amd boxes are in
      *
      *@return the box if a character's location matches said box
      */
    public Box isOnBox(Room room) {
        for (Box box: room.getBoxes()) {
            if (getPosition().equals(box.getPosition())) {
                return box;
            }
        }
        return null;
    }

    /**
      *checks if the character is on a portal
      *
      *@param room the room the character and portals are in
      *
      *@return the portal if the character's location matches said portal
      */
    public Portal isOnPortal(Room room) {
        for (Portal portal: room.getPortals()) {
            if (getPosition().equals(portal.getPosition())) {
                return portal;
            }
        }
        return null;
    }

    /**
      *this method performs one round of battle between two characters
      *
      *@param other the playable character
      *@param room the room the characters are in
      *@param enemies the arraylist that stores all enemies
      *
      *@return false if the player has died aas a result
    */
    public void fight(Character other, Room room, ArrayList<Enemy> enemies) {

        boolean killed = false;

        // check if both characters are alive
        if (isAlive() && other.isAlive()) {

            // do damage to them first
            killed = dealDamage(other, room);
            CustomTerminal.warpCursor(room.getRows() + 2, 0);
            System.out.print("Press any key to return...\n\r");
            Terminal.getKey();

            // don't allow dead enemies to fight back
            if (killed) {
                other.notAlive();
                return;
            }

            // now take damage from them
            if (other.dealDamage(this, room)) {
                notAlive();
            }
            CustomTerminal.warpCursor(room.getRows() + 2, 0);
            System.out.print("Press any key to return...\n\r");
            Terminal.getKey();
            // check if character is dead
        } else if (!isAlive()) {
            notAlive();
        }
    }

    /** 
      *heals character based off of item strength
      */
    public void heal(int strength) {
        hp += strength;
    }
}
