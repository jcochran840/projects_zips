
import ansi_terminal.*;
import java.util.ArrayList;

public class TitleSprite implements Runnable {

    private static TitleSprite title;
    private ArrayList<String> titleSprite;
    private Animation titleAnimation;
    private boolean doDisplayTitle;
    private boolean isDisplaying;

    public void run() {

        int waitTime;

        while (true) {

            try {
                Thread.sleep(3000);
            } catch (InterruptedException e){
                return;
            }

            if (doDisplayTitle) {
                isDisplaying = true;
                titleAnimation.playAnimation();
                isDisplaying = false;
            }
        }
    }


    private TitleSprite(ArrayList<String> sprite, Animation animation) {
        titleSprite = sprite;
        titleAnimation = animation;
        doDisplayTitle = true;
        isDisplaying = false;
    }

    public static TitleSprite instanceOf(ArrayList<String> sprite, Animation animation) {
        if (title == null) {
            title = new TitleSprite(sprite, animation);
            return title;
        }
        return title;
    }

    private void printTitle() {
        AnimationRenderer.printSprite(titleSprite, 1, 35);
    }

    public void doNotDisplay() {
        doDisplayTitle = false;
    }

    public void doDisplay() {
        doDisplayTitle = true;
        printTitle();
    }

    public boolean isDisplaying() {
        return isDisplaying;
    }
}
