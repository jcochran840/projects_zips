import ansi_terminal.*;
import java.util.Random;
import java.util.ArrayList;
import java.util.Random;
/**
  *this class controls the specifics about the merchant character
  */
public class Merchant extends Character {
    private Inventory wares;
    private String name;
    public static final Color MERCHANT_COLOR = Color.GREEN;
    private static Random rng = new Random();
    private boolean battleActive;

    /**
      *merchant constructor
      *
      *@param name the merchant name
      *@param row the horizontal position
      *@param col the vertical position
      *@param wares the merchants personal inventory
      */
    public Merchant(String name, int row, int col, Inventory wares){
        super(row, col, 'M', MERCHANT_COLOR,1);
        this.name = name;
        this.wares = wares;
    }

    /**
      *gets the merchants inventory
      *
      *@return what the merchant is selling
      */
    public Inventory getInventory() {
        return wares;
    }

    /**
      *gets the merchant name
      *
      *@return the merchant's name
      */
    @Override
        public String getName() {
            return name;
        }


    /**
      *gets the merchants damage, hardcoded at 999
      *
      *@return the merchant's damage;
      */
    
    @Override
        public int getDamage() {
            return 999;
        }

    /**
      *gets the merchants defense, hardcoded at 999
      *
      *@return the merchant's defense
      */
    @Override
        public int getProtection() {
            return 999;
        }

    /**
      *checks if the merchant is in battle state
      *
      *@return if the merchant is in a state for battle
      */
    public boolean isBattleActive() {
        return battleActive;
    }

    /**
      *activates state of battle for merchant
      */
    public void setBattleActive() {
        battleActive = true;
    }


    /**
      *the merchant walks around
      *
      *@param room the room the merchant is in
      *@param player the player character
      *@param enemies the ArrayList of enemies
      *@param merchants the ArrayList of merchants
      */
    public void walk(Room room, Player player, ArrayList<Enemy> enemies, ArrayList<Merchant> merchants) {

        int choice = rng.nextInt(4);
        battleActive = false;
        boolean doesMove = (rng.nextInt(4) + 1 <= 2);

        // checks if merchant wants to move and is in distance of the player;
        if (doesMove) {
            switch (choice) {
                case 0:
                    if (isOnEnemy(0, 1, enemies) != null || isOnMerchant(0, 1, merchants) != null || isOnPlayer(0, 1, player)) {
                        return;
                    }
                    move(0, 1, room);
                    return;
                case 1:
                    if (isOnEnemy(0, -1, enemies) != null || isOnMerchant(0, -1, merchants) != null || isOnPlayer(0, -1, player)) {
                        return;
                    }
                    move(0, -1, room);
                    return;
                case 2:
                    if (isOnEnemy(1, 0, enemies) != null || isOnMerchant(1, 0, merchants) != null || isOnPlayer(1, 0, player)) {
                        return;
                    }
                    move(1, 0, room);
                    return;
                case 3:
                    if (isOnEnemy(-1, 0, enemies) != null || isOnMerchant(-1, 0, merchants) != null || isOnPlayer(-1, 0, player)) {
                        return;
                    }
                    move(-1, 0, room);
                    return;
            }
        }
    }
}
