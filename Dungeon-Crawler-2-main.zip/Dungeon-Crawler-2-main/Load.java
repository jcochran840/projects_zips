import ansi_terminal.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
/**
  *this class loads a previous game state from a save file
  */
public class Load {

    /**
      *hypdrates save files and returns saved world data
      *
      *@param scanner used to read in the game state from a file
      *
      *@throws an exception if the read in file is not found
      */
    public static World load(Scanner scanner) throws FileNotFoundException{

        // will hold the saved world
        World world = new World();

        // list saved rooms
        ArrayList<Room> rooms = new ArrayList<>();

        // list of saved enemies for each room
        ArrayList<Enemy> enemies;

        // list of saved boxes for each room
        ArrayList<Box> boxes;

        // list of saved portals for each room
        ArrayList<Portal> portals;

        // list of saved merchants for each room
        ArrayList<Merchant> merchants;

        // map of each room
        ArrayList<String> grid;

        Room defaultRoom = new Room();

        // saved player information (health, position, equiptment)
        Player player = new Player(defaultRoom.getPlayerStart(), defaultRoom, "Player", "Default", 100);
        String playerName;
        String playerCode;
        int playerGold;
        int playerRow;
        int playerCol;
        Position startPosition;
        int playerHealth;
        String playerLocationName;
        Room playerLocation;
        Item playerWeapon;
        Item playerArmor;
        Inventory playerInventory;

        // list of hydrated items
        ArrayList<Item> items = new ArrayList<>();

        // placeholder for hydrating items
        String itemName = "default";
        ItemType itemType = ItemType.Other;
        int itemWeight = 0;
        int itemStrength = 0;
        int itemValue = 0;

        // hardcoded to read 3 rooms from the save file
        for (int x = 1; x <= 3; x++ ) {
            enemies = new ArrayList<>();
            boxes = new ArrayList<>();
            portals = new ArrayList<>();
            merchants = new ArrayList<>();
            grid = new ArrayList<>();

            // grabs room name, opens map file with corresponding room name, and stores map data into grid
            String roomName = scanner.nextLine().trim();

            // stores temporary marker in save file and enters into map file
            // if the program cannot find the map file, stop the program
            Scanner marker = scanner;
            try {
                File mapFile = new File(roomName + ".map");
                scanner = new Scanner(mapFile);
            } catch (Exception e) {
                CustomTerminal.warpCursor(1,0);
                System.out.println("Cannot find " + roomName + ".map" + ".");
                throw new FileNotFoundException();
            }
            while (scanner.hasNextLine()) {
                grid.add(scanner.nextLine());
            }

            // returns to save file

            scanner = marker;
            // discards 'List'O'Enemies...' text
            scanner.nextLine();

            // creates new enemies and adds to list of enemies until a '~~~' delimiter is reached
            String temp = scanner.nextLine();
            while(!temp.equals("~~~")) {

                // pulls saved enemy data
                String name = temp;
                int row = Integer.parseInt(scanner.nextLine().trim());
                int col = Integer.parseInt(scanner.nextLine().trim());
                int health = Integer.parseInt(scanner.nextLine().trim());
                int damage = Integer.parseInt(scanner.nextLine().trim());
                int protection = Integer.parseInt(scanner.nextLine().trim());
                int speed = Integer.parseInt(scanner.nextLine().trim());

                // stores the enemy into list of enemies for the room
                enemies.add(new Enemy(name, row, col, health, damage, protection, speed));
                // discards '%%%' separator
                scanner.nextLine();
                temp = scanner.nextLine();
            }

            // discards 'List'O'Boxes...' text
            scanner.nextLine();
            // creates new boxes and adds to list of boxes until a '~~~' delimiter is reached
            temp = scanner.nextLine();
            while(!temp.equals("~~~")) {

                // pulls saved box data
                String name = temp;
                int row = Integer.parseInt(scanner.nextLine().trim());
                int col = Integer.parseInt(scanner.nextLine().trim());
                ItemType boxType = ItemType.valueOf(scanner.nextLine().trim());
                int weight = Integer.parseInt(scanner.nextLine().trim());
                int strength = Integer.parseInt(scanner.nextLine().trim());
                int value = Integer.parseInt(scanner.nextLine().trim());

                // stores the item, places it into a Box, and stores the Box in list of boxes for the room
                Item item = new Item(boxType, name, weight, value, strength);
                boxes.add(new Box(row, col, item));

                // discards '%%%' separator
                scanner.nextLine();
                temp = scanner.nextLine().trim();
            }

            // discards 'List'O'Portals...' text
            scanner.nextLine();

            // creates new portals and addes to list of portals until a '~~~' delimiter is reached
            temp = scanner.nextLine();
            while(!temp.equals("~~~")) {

                // pulls saved portal data
                int row = Integer.parseInt(temp.trim());
                int col = Integer.parseInt(scanner.nextLine().trim());
                String name = scanner.nextLine();
                String target = scanner.nextLine();

                // sotres portal into list of portals for the room
                portals.add(new Portal(row, col, name, target));
                // discards '%%%' separator
                scanner.nextLine();
                temp = scanner.nextLine().trim();
            }

            // discards "'List'O'Merchants" text
            scanner.nextLine();

            // creates new merchants, hydrates merchants' inventories, and adds to list of merchants until a '~~~' is reached
            temp = scanner.nextLine();
            while(!temp.equals("~~~")) {
                String merchantName = temp;
                Inventory merchantInventory = new Inventory(999);
                int merchantRow = Integer.parseInt(scanner.nextLine().trim());
                int merchantCol = Integer.parseInt(scanner.nextLine().trim());
                // discards "Merchant name's wares:" text
                scanner.nextLine();
                temp = scanner.nextLine();
                while (!temp.equals("~~~")) {
                    itemName = temp.trim();
                    itemType = ItemType.valueOf(scanner.nextLine().trim());
                    itemWeight = Integer.parseInt(scanner.nextLine().trim());
                    itemStrength = Integer.parseInt(scanner.nextLine().trim());
                    itemValue = Integer.parseInt(scanner.nextLine().trim());
                    // discards '%' symbol
                    scanner.nextLine();

                    // adds new item to merchant's inventory
                    merchantInventory.add(new Item(itemType, itemName, itemWeight, itemValue, itemStrength));

                    temp = scanner.nextLine();
                }

                // creates merchant and adds to list of merchants in a room
                merchants.add(new Merchant(merchantName, merchantRow, merchantCol, merchantInventory));

                temp = scanner.nextLine();
            }

            // creates a new room with stroed map portal, box, enemy, and merchant data
            rooms.add(new Room(grid, portals, boxes, enemies, merchants, roomName));

            // discards '~~~END...' text
            scanner.nextLine();
        }

        // tells player the room is ready to be created
        CustomTerminal.warpCursor(1,0);
        System.out.print("Creating new room...");

        // discards "[name] statis " text
        scanner.nextLine();

        // pulls saved player data
        playerName = scanner.nextLine();
        playerCode = scanner.nextLine();
        playerGold = Integer.parseInt(scanner.nextLine().trim());
        playerRow = Integer.parseInt(scanner.nextLine().trim());
        playerCol = Integer.parseInt(scanner.nextLine().trim());
        playerHealth = Integer.parseInt(scanner.nextLine().trim());
        playerLocationName = scanner.nextLine().trim();

        // stores room that player was known to be in when the world was saved;
        // if the player was in none of the rooms, make the player be in the default
        // room (rOne)
        playerLocation = new Room();
        for (Room r: rooms) {
            if (r.getName().equals(playerLocationName)) {
                playerLocation = r;
                break;
            }
        }

        // discards "Player equipped weapon" text
        scanner.nextLine();
        String equipWeapon = scanner.nextLine().trim();

        // discards "Player equipped armor" text
        scanner.nextLine();
        String equipArmor = scanner.nextLine().trim();

        // discards "[name]'s inventory:" text
        scanner.nextLine();
        while(scanner.hasNextLine()) {

            // pulls item data
            itemName = scanner.nextLine();
            itemType = ItemType.valueOf(scanner.nextLine().trim());
            itemWeight = Integer.parseInt(scanner.nextLine().trim());
            itemStrength = Integer.parseInt(scanner.nextLine().trim());
            itemValue = Integer.parseInt(scanner.nextLine().trim());
            items.add(new Item(itemType, itemName, itemWeight, itemValue, itemStrength));

            // discard `%` separator
            scanner.nextLine();
        }

        // grabs starting position of player
        startPosition = new Position(playerRow, playerCol);

        // creates player from saved data
        player = new Player(startPosition, playerLocation, playerName, playerCode, playerGold);

        // adds saved items of the player's inventory to the player's inventory
        for (Item i: items) {
            player.getInventory().add(i);
        }

        playerInventory = player.getInventory();

        // equips the saved equiptment of the player
        for (Item i: items) {
            if (i.getName().equals(equipWeapon)) {
                playerInventory.equip(i);
                break;
            }
        }
        for (Item i: items) {
            if (i.getName().equals(equipArmor)) {
                playerInventory.equip(i);
                break;
            }
        }

        // creates and returns the saved world
        world = new World(rooms, player);
        return world;
    }

    /**
      *used when player inputs game data (name of player, name of save file, etc)
      *
      *@return the players input for a save selection
      */
    public static String saveSelection() {

        // stores file names of save files
        ArrayList<String> fileNames = new ArrayList<>();

        // stores name of selected save file, or other options
        String selection = "";

        Terminal.clear();

        try {
            // stores all file names of the working directory into a list
            File workDir = new File(".");
            File[] files = workDir.listFiles();

            int index = 0;

            // makes a smaller list of only .save files
            for (File file: files) {
                if (file.isFile() && file.getName().contains(".save")) {
                    fileNames.add(file.getName());
                }
            }

            // adds "ESCAPE" text for the menu system
            fileNames.add("ESCAPE");

            // prints the prompt and all avaiable save files + ESCAPE option
            Terminal.warpCursor(1,0);
            System.out.print("Which save file would you like to load?");

            Key key = Key.G;
            while (!key.equals(Key.ESCAPE)){
                int pos = 0;
                for (pos = 0; pos < fileNames.size(); pos++) {

                    // marks the currently selected item with MAGENTA
                    if (pos == index) {
                        Terminal.setBackground(Player.PLAYER_COLOR);
                        Terminal.setForeground(Color.BLACK);
                    }
                    Terminal.warpCursor(pos+2,1);
                    if (fileNames.get(pos).equals("ESCAPE")) {
                        System.out.print(fileNames.get(pos));
                    } else {
                        System.out.print(fileNames.get(pos).substring(0,fileNames.get(pos).length()-1-4));
                    }
                    Terminal.reset();
                }

                // gets player input (either moving through list, escaping, or selecting an item)
                key = Terminal.getKey();
                switch(key) {

                    // move up the list
                    case UP:
                        index = Menu.menuBoundaries(index-1, fileNames.size()-1);
                        break;

                        // move down the list
                    case DOWN:
                        index = Menu.menuBoundaries(index+1, fileNames.size()-1);
                        break;

                        // select an option
                    case ENTER:
                        if (!fileNames.get(index).equals("ESCAPE")) {
                            selection = fileNames.get(index);
                        }

                        // escape the menu
                    case ESCAPE:
                        key = Key.ESCAPE;
                }
            }
            // tells user if there are no save files; exits menu
        } catch (Exception e) {
            System.out.print("No save files.");
            Terminal.getKey();
            return "";
        }

        // return player's option
        return selection;
    }
}
