// Game.java
// contains logic for running the Game

import java.util.ArrayList;
import java.util.Arrays;
import ansi_terminal.*;
import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
/**
  *contains logic for running the Game
  */
public class Game {
    private World world;
    private Room room;
    private Player player;
    private ArrayList<Box> boxes;
    private ArrayList<Enemy> enemies;
    private ArrayList<Merchant> merchants;
    private ArrayList<Portal> portals;
    private static ArrayList<Enemy> deadEnemies = new ArrayList<>();
    private File saveFile;
    private static String storyText = "The life of a traveling merchant is not easy, but it’s the life you chose. "
        + "After years of practice, trade had become second nature. "
        + "You had developed an eye for spotting goods that had a hidden value. "
        + "A silver key, with an unusual design at the end, had just recently come into your possession. "
        + "“What lock do you open?” You mutter the phrase to yourself as you gaze at the key under the light of the full moon. "
        + "When held just right, the key shines with a beautiful light, a light that suddenly intensifies to the point where you must shield your eyes. "
        + "You open them with a feeling of unnerve about you. "
        + "You scan your surroundings and realize that you’ve been transported somewhere... somewhere that you can only describe as a dungeon.";

    private static final String introFileLocation = "intro.frames";
    private static final String titleShineFileLocation = "title_shine.frames";

    private TitleSprite titleScreen;
    private Thread titleThread;

    // valid actions the player can take while in the game
    private static final ArrayList<Key> validActions = new ArrayList<>(Arrays.asList(
                Key.UP,
                Key.DOWN,
                Key.LEFT,
                Key.RIGHT,
                Key.ESCAPE,
                Key.m,
                Key.o,
                Key.p
                ));

    /**
      *game constuctor; creates
      */
    public Game() {
        createState("Player", "Default");
        Terminal.clear();
    }

    /**
      * runs the  main menu
      *loads the intro frames from a file, pauses and then displays the menu options to the player
      *allows the player to start a new game, load and save from the menu
      */
    public void mainMenu() {
        int option = 0;
        int numOptions = Menu.getMainMenuOptions().length - 1;

        File introFile = new File(introFileLocation);
        File titleFile = new File(titleShineFileLocation);
        ArrayList<String> title = new ArrayList<>();
        Animation introAnimation = new Animation();
        Animation titleAnimation = new Animation();

        // attemps to load intro animation from intro.frames
        // if it fails, then skip the intro animation
        try {
            Scanner in = new Scanner(introFile);
            introAnimation = new Animation(in, introFileLocation, 1, 35);
            in.close();

            // grabs last frame of the intro animation and stores as the title text
            title = introAnimation.getFrame(introAnimation.size()-1);

        } catch (Exception e) {
            System.out.print("Cannot load \"" + introFileLocation + "\"!");
            Terminal.pause(3);
        }

        // attempts to load title screen animation from title_shine.frames
        // if it fails, then skip the title animation
        try {
            Scanner in = new Scanner(titleFile);
            titleAnimation = new Animation(in, titleShineFileLocation, 1, 35);
            in.close();
        } catch (Exception e) {
            System.out.print("Cannot load \"" + titleShineFileLocation + "\"");
        }

        // plays intro animation
        if (introAnimation != null) {
            introAnimation.playAnimation();
        }

        if (title.size() > 0) {
            titleScreen = TitleSprite.instanceOf(title, titleAnimation);
            Runnable r = titleScreen;
            titleThread = new Thread(r);
            titleThread.start();
        }

        // wait a bit for the title to appear
        try {
            Thread.sleep(300);
        } catch (InterruptedException e){return;}

        Key key = Key.G;
        while (!key.equals(Key.ESCAPE)) {

            // prints main menu options
            Menu.printMainMenu(option);

            key = Terminal.getKey();

            switch(key) {
                case UP:
                    option = Menu.menuBoundaries(option - 1, numOptions);
                    break;
                case DOWN:
                    option = Menu.menuBoundaries(option + 1, numOptions);
                    break;

                    // select an option
                case ENTER:
                    titleScreen.doNotDisplay();
                    if (titleScreen.isDisplaying()) {
                        Terminal.pause(0.5);
                    }
                    Terminal.clear();
                    switch(option) {

                        // start a new game
                        case 0:

                            key = Key.G;

                            // player names their character
                            String name = Menu.inputName(10, 50, "Enter your name: ", "");

                            // if the player attempts to name a character with no character or
                            // player exits the naming screen, then exit the new game screen
                            if (name.equals("") || name.equals("ESCAPE")) {
                                titleScreen.doDisplay();
                                break;
                            }

                            // player inputs code; some codes do special things to the game
                            String playerCode = Menu.inputName(10, 50, "Input your code: ", "");


                            // exit new game screen if player attempts to name their race with no characters or
                            // player exits the naming screen
                            if (playerCode.equals("") || playerCode.equals("ESCAPE")) {
                                titleScreen.doDisplay();
                                break;
                            }

                            createState(name, playerCode);

                            // asks if player wants to skip the introduction text
                            while (!key.equals(Key.ESCAPE) && !key.equals(Key.y) && !key.equals(Key.n)) {
                                CustomTerminal.warpCursor(5, 0);
                                System.out.print("Do you want to skip the intro? (y/n)");
                                key = Terminal.getKey();
                            }

                            // exits new game and returns to main menu
                            if (key.equals(Key.ESCAPE)) {
                                key = Key.G;
                                Terminal.clear();
                                titleScreen.doDisplay();
                                break;
                            }

                            // plays the introduction text
                            if (!key.equals(Key.y)) {
                                printIntro();
                            }

                            // begins the game
                            run();
                            Terminal.clear();
                            if (titleScreen != null) {
                                titleScreen.doDisplay();
                            }
                            break;

                            // player wants to load a .save file;
                            // if a .save file is loaded, the game starts;
                            // else, the player returns to the main menu
                        case 1:
                            String answer = Load.saveSelection();
                            if (!answer.equals("")) {
                                loadState(answer);
                            } else {
                                Terminal.clear();
                                titleScreen.doDisplay();
                                break;
                            }
                            run();
                            Terminal.clear();
                            if (titleScreen != null) {
                                titleScreen.doDisplay();
                            }
                            break;

                            // exits main menu; ends program
                        case 2:
                            if (titleThread != null) {
                                while (titleThread.isAlive()) {
                                    titleThread.interrupt();
                                }
                            }
                            key = Key.ESCAPE;
                    }
                    break;
                case ESCAPE:
                    if (titleThread != null) {
                        while (titleThread.isAlive()) {
                            titleThread.interrupt();
                        }
                    }
            }

        }
        return;       

    }

    
      //prints the scrolling introduction text before a new game starts
      
    private void printIntro() {
        Terminal.clear();

        int counter = 0;
        int lineCounter = 4;
        while (counter < storyText.length()) {
            CustomTerminal.warpCursor(lineCounter, (counter % 81) + 10);
            if (storyText.charAt(counter) != ' ' && counter % 81 == 80) {
                System.out.print(storyText.charAt(counter) + "-");
            } else {
                System.out.print(storyText.charAt(counter));
                if (storyText.charAt(counter) == '.') {
                    Terminal.pause(0.35);
                }
            }
            counter++;
            if (counter % 81 == 0){
                lineCounter++;
            }
            Terminal.pause(0.042);
        }
        CustomTerminal.warpCursor(lineCounter + 1, 10);
        sleep(3000);
        System.out.print("Press any key to begin...");
        Terminal.getKey();
    }

    
      //attempts to save the game by either writing to a new save file or to a previously used one
      
    private void saveState(){
        try {
            File temp;

            // if the world is new, attempts to save a new save file
            if (saveFile == null) {
                String name = Menu.inputName(room.getRows(), 0, "Name your save file: ", ".save");

                // player attemps to name a save file with no character
                if (name.equals("")) {
                    throw new FileNotFoundException();
                }

                // player exits from the naming save file section
                if (name.equals("ESCAPE")){
                    return;
                }

                // if the world is from a save file, then save to that file
                temp = new File(name); 
            } else {
                temp = saveFile;
            }
            PrintWriter p = new PrintWriter(temp);
            Save.save(player, p, world, room);
            p.close();

            // game is now marked as part of the newly created save fule
            saveFile = temp;

            // tells player if save file or associated files (ex: .map files) could not be loaded
        } catch (FileNotFoundException e) {
            CustomTerminal.warpCursor(room.getRows() + 1, 0);
            setStatus("Could not save file!");
            Terminal.pause(1.5);
            CustomTerminal.warpCursor(room.getRows() + 1, 0);
            System.out.print("                                 ");
        }
    }

    
      //attempts to load the game;
      //if an error occurs, a new game will load
      
    private void loadState(String fileName) {
        Terminal.clear();
        File save = new File(fileName);
        if (save.exists()) {
            try {
                Scanner in = new Scanner(save);
                CustomTerminal.warpCursor(1,0);
                System.out.print("Reading save file...");
                world = Load.load(in);
                player = world.getPlayer();
                room = player.getPlayerLocation();
            } catch (FileNotFoundException e) {
                CustomTerminal.warpCursor(2,0);
                System.out.print("Could not load save file...");
                Terminal.pause(1.5);
            }

        } else {
            createState("Player", "Default");
            return;
        }
        boxes = room.getBoxes();
        enemies = room.getEnemies();
        portals = room.getPortals();
        merchants = room.getMerchants();
        saveFile = save;

    }

    // create a new world
    private void createState(String name, String race) {

        int row = 1;

        // clears terminal
        Terminal.clear();

        // loading default room
        room = new Room();

        // creates default player
        CustomTerminal.warpCursor(row,0);
        System.out.print("Creating new player...");
        player = new Player(room.getPlayerStart(), room, name, race, 100);
        player.giveStartingEquiptment();
        row++;

        // creates default world
        CustomTerminal.warpCursor(row,0);
        System.out.print("Making new world...");
        world = WorldGenerator.generate(player);
        row++;

        // creates default room that player will start in
        CustomTerminal.warpCursor(row,0);
        System.out.print("Loading first room...");
        room = world.getRooms().get(0);
        row++;

        // grabs enemies, portals, and boxes form default world
        CustomTerminal.warpCursor(row,0);
        System.out.print("Filling rooms...");
        row++;
        merchants = room.getMerchants();
        boxes = room.getBoxes();
        enemies = room.getEnemies();
        portals = room.getPortals();

        // marks that game has no associated save file
        saveFile = null;
    }

    // prints a help menu to the left of the map
    private void showHelp() {
        String[] cmds = {
            "\u0A6D~~~~~~~~~~~~~~~~~~~~\u0A6D",
            "\u2502      Commands:     \u2502",
            "\u2502      ---------     \u2502",
            "\u2502   Move: Arrow Keys \u2502",
            "\u2502  Pickup an item: p \u2502",
            "\u2502      Quit: ESC     \u2502",
            "\u2502       Warp: o      \u2502",
            "6~~~~~~~~~~~~~~~~~~~~6"
        };
        Terminal.setForeground(Color.GREEN);
        int row = 0;
        for (row = 0; row < cmds.length; row++) {
            CustomTerminal.warpCursor(row + 1, room.getCols() + 2);
            System.out.print(cmds[row]);
        }
        Terminal.reset();

    }

    // prints game information such as player health, room completion, and game completion
    private void drawGameInfo() {
        int row = 11;

        drawGameInfoMove(row);
        System.out.print("\u0A6D~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\u0A6D");
        row++;

        // prints the current room's name and if the current room is completed
        drawGameInfoMove(row);
        //System.out.print("`" + room.getName() + " Completion: ");
        System.out.printf("\u2502%14s Completion: ", room.getName() + "'s");
        if (roomClear()) {
            Terminal.setForeground(Color.GREEN);
            System.out.print("Done!         ");
        } else {
            Terminal.setForeground(Color.RED);
            System.out.print("Incomplete!   ");
        }
        Terminal.reset();
        System.out.print("\u2502");
        row++;

        // prints game completion
        String gameProgressBar = "";
        int numRoomsComplete = 0;
        for (Room r: world.getRooms()) {
            if (r.getEnemies().size() == 0) {
                numRoomsComplete++;
            }
        }
        int integerComplete = (int)(( (double)(numRoomsComplete) / (double)(world.getRooms().size()) ) * 10);
        int percentComplete = (int)(( (double)(numRoomsComplete) / (double)(world.getRooms().size()) ) * 100);
        for (int x = 1; x <= 10; x++) {
            if (x <= integerComplete) {
                gameProgressBar += "\u2588";
            } else {
                gameProgressBar += " ";
            }
        }
        drawGameInfoMove(row);
        System.out.print("\u2502    Game completion: [");
        Terminal.setForeground(Color.MAGENTA);
        System.out.print(gameProgressBar);
        Terminal.reset();
        System.out.printf("] %-7s\u2502", percentComplete + "%");
        row++;
        Terminal.reset();

        // prints the player's health
        String healthBar = "";
        int integerHealth = (int)( (( (double)(player.getHealth()) / (double) (Player.MAX_PLAYER_HEALTH))) * 10);
        int percentHealth = (int)((( (double)(player.getHealth()) / (double) (Player.MAX_PLAYER_HEALTH))) * 100);
        drawGameInfoMove(row);
        for (int x = 1; x <= 10; x++){
            if (x <= integerHealth) {
                healthBar += "\u2588";
            } else {
                healthBar += " ";
            }
        }
        drawGameInfoMove(row);
        System.out.printf("\u2502%12s health: [", player.getName() + "'s");
        Terminal.setForeground(Color.GREEN);
        System.out.print(healthBar);
        Terminal.reset();
        System.out.printf("] %-7s\u2502", percentHealth + "%");
        row++;

        // draws the player's gold
        drawGameInfoMove(row);
        System.out.printf("\u2502%12s's gold: ", player.getName());
        System.out.printf("%-20d\u2502", player.getGold());
        row++;

        drawGameInfoMove(row);
        System.out.print("6~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~6");
    }

    private void drawGameInfoMove(int row) {
        CustomTerminal.warpCursor(row, room.getCols() + 2);
    }

    // right under the map we keep a line for status messages
    private void setStatus(String mesg) {
        // clear anything old first
        for (int x = 0; x < 3; x++) {
            CustomTerminal.warpCursor(room.getRows() + x, 0);
            for (int i = 0; i < 100; i++) {
                System.out.print(" ");
            }
        }

        // then print the message
        CustomTerminal.warpCursor(room.getRows(), 0);
        System.out.print(mesg);
    }

    // code for when the player tries to pickup an item
    private void pickup() {
        Box thing = checkForBox();
        if (thing == null) {
            setStatus("There is nothing here to pick up...");
            Terminal.pause(1.25);
        } else {
            if (player.getInventory().add(thing.getItem())) {
                setStatus("You added the " + thing.getItem().getName() + " to your inventory.");
                boxes.remove(thing);
            } else {
                setStatus("This is too large for you to add!");
            }
            Terminal.pause(1.25);
        }
    }

    // allows the player to use portals if the player is on a portal;
    // when the player warps, the current room is changed
    private void warp() {
        Portal portal = checkForPortal();
        if (portal == null) {
            setStatus("There is no portal...");
            Terminal.pause(1.25);
        } else {
            String target = portal.getTarget();
            for (Room r : world.getRooms()){
                if(!r.equals(room)){
                    for (Portal port: r.getPortals()) {
                        if (port.getName().equals(target)) {

                            setStatus("Warping to " + port.getName() + "...");

                            setRoom(r);
                            portals = room.getPortals();
                            enemies = room.getEnemies();
                            boxes = room.getBoxes();
                            merchants = room.getMerchants();

                            // warp animation
                            for (int x = 1; x <= 5; x++) {
                                player.draw(Color.YELLOW);
                                Terminal.warpCursor(1,0);
                                Terminal.pause(0.1);
                                player.draw();
                                Terminal.warpCursor(1,0);
                                Terminal.pause(0.1);
                            }

                            player.setRow(port.getRow());
                            player.setCol(port.getCol());
                            redrawMapAndHelp();
                            break;
                        }
                    }
                }
            }
        }
    }

    // code for when the player tries to drop an item
    private void drop() {
        if (checkForBox() == null) {
            Item dropped = player.getInventory().drop();
            if (dropped != null) {
                boxes.add(new Box(player.getRow(), player.getCol(), dropped));
            }
            redrawMapAndHelp();
        } else {
            setStatus("You cannot drop something on an existing item...");
            Terminal.pause(1.25);
        }
    }

    private void interact(Player p, Merchant m) {
        Key key = Key.G;
        while (!key.equals(Key.ESCAPE) && !key.equals(Key.b) && !key.equals(Key.s)) {
            setStatus("\u263A You (b)uyin' or (s)ellin'?");
            key = Terminal.getKey();
        }
        if (key.equals(Key.b)) {
            m.getInventory().buyItem(p, m);
        }
        else if (key.equals(Key.s)) {
            p.getInventory().sellItem(p);
        }
        else if (key.equals(Key.ESCAPE)) {
            setStatus("Come back when you change your mind!");
        }
    }

    // handle the key which was read - return false if we quit the game
    private boolean handleKey(Key key) {
        Enemy opponent;
        Merchant vendor;
        switch (key) {

            // player wants to use a portal
            case o:
                warp();
                break;

                // player wants to pickup a box
            case p:
                pickup();
                break;

                // player opens the game menu
            case m:
                int option = 0;
                Key input = Key.G;
                while (!input.equals(Key.ESCAPE)) {
                    Menu.printGameMenu(room.getRows() + 1, room.getCols(), option);
                    input = Terminal.getKey();
                    switch(input) {
                        case UP:
                            option = Menu.menuBoundaries(option - 1, Menu.getGameMenuOptions().length-1);
                            break;
                        case DOWN:
                            option = Menu.menuBoundaries(option + 1, Menu.getGameMenuOptions().length-1);
                            break;
                        case ENTER:
                            switch(option) {
                                // prints the player's inventory on screen for viewing
                                case 0:
                                    player.getInventory().print();
                                    redrawMapAndHelp();
                                    drawEntities();
                                    break;
                                    // allows player to select an item from their inventory to potentially use
                                case 1:
                                    Item selection = player.getInventory().useItem();
                                    // if the selected item is a potion
                                    if (selection != null && selection.getName().equals("Potion")) {
                                        // heals player and removes potion from player's inventory
                                        player.heal(selection.getStrength());
                                        player.getInventory().getItems().remove(selection);
                                    }
                                    redrawMapAndHelp();
                                    drawEntities();
                                    break;
                                    // allows player to equip a weapon
                                case 2:
                                    player.getInventory().equipWeapon();
                                    redrawMapAndHelp();
                                    drawEntities();
                                    break;
                                    // allows player to equip armor
                                case 3:
                                    player.getInventory().equipArmor();
                                    redrawMapAndHelp();
                                    drawEntities();
                                    break;
                                    // allows player to drop an item from their inventory
                                case 4:
                                    player.getInventory().drop();
                                    redrawMapAndHelp();
                                    drawEntities();
                                    break;
                                    // allows player to save game
                                case 5:
                                    saveState();
                                    break;
                                    // allows player to exit game menu
                                case 6:
                                    input = Key.ESCAPE;
                            }

                            // redraws game info in case of any changes
                            drawGameInfo();
                            break;
                        case ESCAPE:
                            input = Key.ESCAPE;
                    }
                }
                redrawMapAndHelp();
                break;

                // handles movement;
                // checks if player is on an enemy or merchant;
                // if the player is on an enemy, start a battle;
                // if the player is on a merchant, enter the shop

                // player wants to move left
            case LEFT:

                opponent = player.isOnEnemy(0, -1, enemies);
                vendor = player.isOnMerchant(0, -1, merchants);
                if (opponent != null) {
                    player.fight(opponent, room, enemies);
                    break;
                }
                if (vendor != null){
                    interact(player, vendor);
                    redrawMapAndHelp();
                    drawEntities();
                    break;
                }
                player.move(0, -1, room);
                break;

                // player wants to move right
            case RIGHT:
                opponent = player.isOnEnemy(0, 1, enemies);
                vendor = player.isOnMerchant(0, 1, merchants);
                if (opponent != null) {
                    player.fight(opponent, room, enemies);
                    break;
                }
                if (vendor != null){
                    interact(player, vendor);
                    redrawMapAndHelp();
                    drawEntities();
                    break;
                }
                player.move(0, 1, room);
                break;

                // palyer wants to move up
            case UP:
                opponent = player.isOnEnemy(-1, 0, enemies);
                vendor = player.isOnMerchant(-1, 0, merchants);
                if (opponent != null ) {
                    player.fight(opponent, room, enemies);
                    break;
                }
                if (vendor != null){
                    interact(player, vendor);
                    redrawMapAndHelp();
                    drawEntities();
                    break;
                }
                player.move(-1, 0, room);
                break;

                // player wants to move down
            case DOWN: 
                opponent = player.isOnEnemy(1, 0, enemies);
                vendor = player.isOnMerchant(1, 0, merchants);
                if (opponent != null) {
                    player.fight(opponent, room, enemies);
                    break;
                }
                if (vendor != null){
                    interact(player, vendor);
                    redrawMapAndHelp();
                    drawEntities();
                    break;
                }
                player.move(1, 0, room);
                break;

                // and finally the quit command
            case ESCAPE:
                while (true) {
                    setStatus("Are you sure you want to quit? (y) or (n)");
                    key = Terminal.getKey();
                    if (key.equals(Key.ESCAPE) || key.equals(Key.n) || key.equals(Key.N)) {
                        break;
                    } else if (key.equals(Key.y) || key.equals(Key.Y)) {
                        return false;
                    }
                }
        }

        return true;
    }

    // this is called when we need to redraw the room and help menu
    // this happens after going into a menu like for choosing items
    private void redrawMapAndHelp() {
        room.draw();
        showHelp();
    }

    /**
      *draws the entities within the room
      */
    public void drawEntities() {


        // renders all boxes in the room;
        for (Box box : boxes) {
            box.draw();
        } 

        // renders all portals in the room;
        for(Portal portal : portals) {
            portal.draw();
        }

        // renders all merchants in the room;
        // if merchant is on a box, the merchant's color is that of the box;
        // if enemy is on a portal, the merchant's color is that of the portal
        Color merchantColor = Merchant.MERCHANT_COLOR;
        for (Merchant merchant : merchants) {
            if (merchant.isOnBox(room) != null) {
                merchantColor = Box.BOX_COLOR;
            } else if (merchant.isOnPortal(room) != null) {
                merchantColor = Portal.PORTAL_COLOR;
            } else {
                merchantColor = Merchant.MERCHANT_COLOR;
            }
            merchant.draw();
        }

        // renders all enemies in the room;
        // if enemy is on a box, enemy's color is that of the box;
        // if enemy is on a portal, enemy's color is that of the portal
        Color enemyColor = Enemy.ENEMY_COLOR;
        for (Enemy enemy : enemies) {
            if (enemy.isOnBox(room) != null) {
                enemyColor = Box.BOX_COLOR;
            } else if (enemy.isOnPortal(room) != null) {
                enemyColor = Portal.PORTAL_COLOR;
            } else {
                enemyColor = Enemy.ENEMY_COLOR;
            }
            enemy.draw(enemyColor);
        }

        // renders player
        Color playerColor = Player.PLAYER_COLOR;

        if (player.isOnBox(room) != null) {
            playerColor = Box.BOX_COLOR;
        } else if (player.isOnPortal(room) != null) {
            playerColor = Portal.PORTAL_COLOR;
        }

        player.draw(playerColor);
    }

    // returns a Box if the player is on it -- otherwise null
    private Box checkForBox() {
        Position playerLocation = player.getPosition();

        for (Box box : boxes) {
            if (playerLocation.equals(box.getPosition())) {
                return box;
            }
        }

        return null;
    }

    // checks if the player is on a portal
    private Portal checkForPortal() {
        Position playerLocation = player.getPosition();

        for (Portal portal : room.getPortals()) {
            if (playerLocation.equals(portal.getPosition())){
                return portal;
            }
        }

        return null;
    }

    // check for battles and return false if player has died
    private void checkBattles() {
        // look for an enemy that is close
        for (Enemy enemy : enemies) {
            if (enemy.isBattleActive() && enemy.isAlive()) {
                player.fight(enemy, room, enemies);
            }
            drawGameInfo();
        }
    }

    /**
      *a game runs
      *draws the map, then entities within
      *checks if the game has been completed or won
      *reads the key inputs from the player
      *removes dead enemies from map and adds them to a list of dead enemie
      *moves the merchants
      *checks if any entities are in battle and handle them accordingly
      *checks if the player has recieved a game over
      *checks if player is on top of boxes and portals and handles them accordingly
      */
    public void run() {
        // draw these for the first time now
        redrawMapAndHelp();

        // draws player, enemies, boxes, and portals
        drawEntities();

        boolean playing = true;
        while (playing) {

            // draws player, enemies, boxes, and portals
            drawEntities();

            // print game info
            drawGameInfo();

            if (gameWin()) {
                CustomTerminal.warpCursor(room.getRows(), 0);
                System.out.print("You win :)  !!!");
                Terminal.getKey();
                Terminal.clear();
                titleScreen.doDisplay();
                return;
            }

            // read a key from the user
            CustomTerminal.warpCursor(room.getRows() + 1, 0);
            Key key = Terminal.getKey();
            playing = handleKey(key);
            if (!validActions.contains(key)) {
                continue;
            }
            // if player exits menu, picks up item, or quits the game, the
            // enemies' turns are skipped
            if (key.equals(Key.m) || key.equals(Key.p) || key.equals(Key.ESCAPE)) {
                continue;
            }

            // clear status by default
            setStatus("");

            // move the enemies in the room
            for (Enemy enemy : enemies) {
                enemy.walk(room, player, enemies, merchants);
            }

            // move the merchants in the room
            for (Merchant merchant : merchants) {
                merchant.walk(room, player, enemies, merchants);
            }

            // draws player, enemies, boxes, and portals
            drawEntities();

            // checks for battles
            checkBattles();

            // adds dead enemies to list of dead enemies
            deadEnemies = new ArrayList<>();
            for (Enemy enemy: enemies) {
                if (!enemy.isAlive()) {
                    deadEnemies.add(enemy);
                }
            }

            // moves any dead enemies
            for (Enemy enemy : deadEnemies) {
                enemies.remove(enemy);
                CustomTerminal.warpCursor(enemy.getRow(),enemy.getCol());
                System.out.print(" ");
            }

            // draw player, enemies, boxes, and portals
            //drawEntities();

            // checks for a game over
            if (!player.isAlive()) {
                setStatus("You have been killed :(\n\r");
                Terminal.getKey();
                playing = false;
            }

            // check if we are on a box and print what's in it
            Box boxHere = checkForBox();
            if (boxHere != null) {
                setStatus("Here you find: " + boxHere.getItem().getName());
            }

            // check if we are on a portal and print where the portal leads
            Portal portalHere = checkForPortal();
            if (portalHere != null) {
                setStatus("Here you find: A portal to " + portalHere.getTarget());
            }

        }

    }

    /**
      *a timer for the game where the player cannot perform any actions during the timer
      *
      *@param time the amount of time the game is paused
      */
    public static void sleep(int time){
        try {
            Thread.sleep(time);
        }catch (Exception e){}
    }

    /**
      *sets the current room to be a specified room
      * 
      *@param room the room to be changed to the current room
      */
    public void setRoom(Room room) {
        this.room = room;
    }

    /**
      *checks if all the enemies in the current room are defeated
      */
    private boolean roomClear(){
        boolean empty = false;
        if (enemies.size() == 0){
            empty =  true;
        }
        return empty;
    }

    /**
      *checks if all the enemies in a specific room are defeated
      *
      *@param r the current room
      */
    private boolean roomClear(Room r){
        boolean empty = false;
        if (r.getEnemies().size() == 0){
            empty = true;
        }
        return empty;
    }

    /**
      *checks if the player has won the game by clearing all the rooms
      */
    private boolean gameWin() {
        int counter = 0;
        for (Room r: world.getRooms()) {
            if (roomClear(r)) {
                counter++;
            }
        }
        if (counter == world.getRooms().size()) {
            return true;
        }
        return false;
    }
}
