// Player.java

import ansi_terminal.*;
import java.util.ArrayList;
/**
  *this clas handles the player character and their equipment
  */
public class Player extends Character {
    private Inventory items;
    private Room playerLocation;
    private String name;
    private String code;
    private int gold;
    public static final int MAX_PLAYER_HEALTH = 50;
    public static final Color PLAYER_COLOR = Color.CYAN;

    /**
      *player constructor
      *
      *@param start the players starting posiation
      *@param playerLocation the player location in the room
      *@param name player name
      *@param code player save code
      *@param gold amount of gold the player starts with
      */
    public Player(Position start, Room playerLocation, String name, String code, int gold) {

        // our starting details
        super(start.getRow(), start.getCol(), '\u20AC', PLAYER_COLOR, MAX_PLAYER_HEALTH);

        this.playerLocation = playerLocation;
        this.name = name;
        this.code = code;
        this.gold = gold;

        // we can carry 100 pounds of items
        items = new Inventory(100);

        // check for special conditions from the inputted code
        checkCode();
    }

    /**
      *adds a basic armor and weapon to the player's inventory
      */
    public void giveStartingEquiptment(){
        items.addAndEquip(new Item(ItemType.Weapon, "Iron Dagger", 5, 12, 7));
        items.addAndEquip(new Item(ItemType.Armor, "Leather Armor", 15, 20, 3));
    }

    /**
      *gets the player damage
      *
      *@return player's damage
      */
    @Override
        public int getDamage() {
            // get our player's weapon
            Item weapon = items.getEquippedWeapon();
            // if we do have a weapon, return the strength of the weapon
            if (weapon != null) {
                return weapon.getStrength();
            } else {
                // if we have no weapon, our fists are pretty weak...
                return 1;
            }
        }

    /**
      *gets the player name
      *
      *@returns player's name
      */
    @Override
        public String getName() {
            return name;
        }

    /**
      *gets the player save code
      *
      *@return code initially inputted by the player
      */
    public String getCode() {
        return code;
    }

    /**
      *gets the player gold
      *
      *@return amount of gold of the player
      */
    public int getGold() {
        return gold;
    }

    /**
      *gets the players current room
      *
      *@return room the player is currently in
      */
    public Room getPlayerLocation() {
        return playerLocation;
    }

    /**
      *gets the player defence
      *
      *@return player's defense
      */
    @Override
        public int getProtection() {
            Item armor = items.getEquippedArmor();
            if (armor != null) {
                return armor.getStrength();
            } else {
                // without armor, we have no protection
                return 0;
            }
        }

    /**
      *gets the player inventory
      *
      *@return the player's inventory
      */
    public Inventory getInventory() {
        return items;
    }

    /**
      *checks the inputted code; specific codes with change how the game starts or runs
      */
    private void checkCode() {

        // player starts the game with 1 health point
        if (code.equals("0000000001")) {
            heal(-49);
        }
    }

    @Override
        /**
	  *heals the player based off the item's strength
	  */
        public void heal(int strength) {
            if (getHealth() + strength > MAX_PLAYER_HEALTH) {
                strength = MAX_PLAYER_HEALTH - getHealth();
            }
            super.heal(strength);
        }

    /**
      *changes the amount of gold the player has
      */
    public void changeGold(int changeAmount) {
        gold += changeAmount;
    }
}

