// Enemy.java

import java.util.Random;
import java.util.ArrayList;
import ansi_terminal.*;
/**
  *this class stores and retrieves enemy stats
  */
public class Enemy extends Character {
    private String name;
    private int damage;
    private int protection;
    private static Random rng = new Random();
    private boolean battleActive;
    private int speed;

    public static final Color ENEMY_COLOR = Color.RED;
/**
  *creates an enemy
  *
  *@param name the enemy name
  *@param row the enemy horizontal position
  *@param col the enemy vertical position
  *@param hp the enemy health
  *@param protection the enemy damage mitigation
  *@param speed the enemy movement speed
  */
    public Enemy(String name, int row, int col, int hp, int damage, int protection, int speed) {
        super(row, col, '*', ENEMY_COLOR, hp);
        this.name = name;
        this.damage = damage;
        this.protection = protection;
        this.battleActive = false;
        this.speed = speed;
    }

    @Override
	    /**
	      *checks damage dealt
	      *
	      *@return the damage number dealt
	      */
	  public int getDamage() {
            return damage;
        }

    @Override
	    /**
	      *checks damage mitigation
	      *
	      *@return the mitigation number
	      */
        public int getProtection() {
            return protection;
        }

    @Override
	    /**
	      *checks for enemy name
	      *
	      *@return the enemy name
	      */
        public String getName() {
            return name;
        }

   /**
     *checks enemy speed
     *
     *@return the enemy movement number
     */
    public int getSpeed() {
        return speed;
    }

    /**
      *puts enemy in combat
      */
    public void setBattleActive() {
        battleActive = true;
    }

    /**
      *takes enemy out of combat
      */
    public void setBattleInActive() {
        battleActive = false;
    }

   /**
     *checks if enemy is in combat
     *
     *@return boolean if enemy is in combat
     */
    public boolean isBattleActive() {
        return battleActive;
    }

    /**
      *randomly move this enemy in the room
      */
    public void walk(Room room, Player player, ArrayList<Enemy> enemies, ArrayList<Merchant> merchants) {

        double distance = Math.sqrt( Math.pow( player.getPosition().getRow() - getPosition().getRow(), 2) + Math.pow( player.getPosition().getCol() - getPosition().getCol(), 2));
        int x_dist =  getPosition().getCol() - player.getPosition().getCol();
        int y_dist = getPosition().getRow() - player.getPosition().getRow();
        int choice = rng.nextInt(4);
        boolean doesMove = (rng.nextInt(EnemyGenerator.ENEMY_MAX_SPEED) + 1 <= speed);
        battleActive = false;

        // checks if enemy wants to move and is in distance of the player;
        // if so, the enemy will move towards the player
        if (doesMove && distance <= 5) {
            if (y_dist < 0) {
                if (isOnPlayer(1, 0, player)) {
                    setBattleActive();
                    return;
                }
                if (isOnEnemy(1, 0, enemies) != null || isOnMerchant(1, 0, merchants) != null) {
                    return;
                }
                move(1, 0, room);
                return;
            }

            if (y_dist > 0) {
                if (isOnPlayer(-1, 0 , player)) {
                    setBattleActive();
                    return;
                }
                if (isOnEnemy(-1, 0, enemies) != null || isOnMerchant(-1, 0, merchants) != null) {
                    return;
                }
                move(-1, 0, room);
                return;
            }

            if (x_dist < 0) {
                if (isOnPlayer(0, 1, player)) {
                    setBattleActive();
                    return;
                }
                if (isOnEnemy(0, 1, enemies) != null || isOnMerchant(0, 1, merchants) != null) {
                    return;
                }
                move(0, 1, room);
                return;
            }

            if (x_dist > 0) {
                if (isOnPlayer(0, -1 , player)) {
                    setBattleActive();
                    return;
                }
                if (isOnEnemy(0, -1, enemies) != null || isOnMerchant(0, -1, merchants) != null) {
                    return;
                }
                move(0, -1, room);
                return;
            }               
        } else if (doesMove){
            switch (choice) {
                case 0:
                    if (isOnEnemy(0, 1, enemies) != null || isOnMerchant(0, 1, merchants) != null) {
                        return;
                    }
                    move(0, 1, room);
                    return;
                case 1:
                    if (isOnEnemy(0, -1, enemies) != null || isOnMerchant(0, -1, merchants) != null) {
                        return;
                    }
                    move(0, -1, room);
                    return;
                case 2:
                    if (isOnEnemy(1, 0, enemies) != null || isOnMerchant(1, 0, merchants) != null) {
                        return;
                    }
                    move(1, 0, room);
                    return;
                case 3:
                    if (isOnEnemy(-1, 0, enemies) != null || isOnMerchant(-1, 0, merchants) != null) {
                        return;
                    }
                    move(-1, 0, room);
                    return;
            }
        }
    }
}
