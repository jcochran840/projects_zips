/**
 * The ItemGenerator class creates random items complete with unique names and stats using random number generators.
 */

import java.util.Random;

public class ItemGenerator {
    private static String[] buildType = {"Rusty","Scrap","Iron","Silver","Brave","Divine","Ultima","Arcane",
            "Corrupted","Chrono","Eldritch","Crystal","Dragon","Demonic","Thunder","Fire","Wind","Water","Earth","Stone","Ice"};
    private static String[] weapon = {"Dagger","Straight Sword","Greatsword","Katana","Axe","Greataxe",
            "Hammer","Claw","Spear","Halberd","Lance","Whip","Bow","Greatbow","Staff","Gunblade","Gun","Tome","Shield","Kusarigama","Odachi"};
    private static String[] armor = {"Helm","Crown","Hood","Mask","Plate","Greave","Cloak","Guard","Boot",
            "Robe","Armor","Gauntlet","Glove","Skirt","Mail","Pauldron","Cuirass","Vambrace","Fauld","Sabaton"};
    private static String[] other = {"Potion"/*,"Flask","Stopwatch","Apple","Bone","Part","Poison","Book","Note","Meat","Cheese"*/};

    /**
     * Randomly generates different items. First the method generates stats for the item then it bicks a number 0-2
     * and assembles an item with a corresponding type by randomly choosing a built type and a weapon, armor, or miscellaneous item
     * type based on which number was generated. Afterwords the name is assigned to the stats previously created and the item
     * is returned as a completed object.
     * @return returns the completed Item object.
     */
    public static Item generate(){
        Random numGen = new Random();
        ItemType iType = null;
        String name = "";
        int weight = numGen.nextInt(10) + 1;
        int value = numGen.nextInt(99);
        int strength = numGen.nextInt(99);

        int choice = numGen.nextInt(3);
        switch(choice) {
            case 0:
                String wType = buildType[numGen.nextInt(buildType.length)];
                String wpn = weapon[numGen.nextInt(weapon.length)];
                name = (wType + " " + wpn);
                iType = ItemType.Weapon;
                break;
            case 1:
                String aType = buildType[numGen.nextInt(buildType.length)];
                String armr = armor[numGen.nextInt(armor.length)];
                name = (aType + " " + armr);
                iType = ItemType.Armor;
                break;
            case 2:
                //String oType = buildType[numGen.nextInt(buildType.length)];
                name = other[numGen.nextInt(other.length)];
                //name = (oType + " " + othr);
                iType = ItemType.Other;
                break;
        }
        Item i = new Item(iType,name,weight,value,strength);
        return i;
    }
}


