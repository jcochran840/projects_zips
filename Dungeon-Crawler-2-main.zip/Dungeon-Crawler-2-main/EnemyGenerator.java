// EnemyGenerator.java


import java.util.Random;
/**
  *this class randomly creates an enemy
  */
public class EnemyGenerator {
    private static final Random rng = new Random();
    public static final int ENEMY_MAX_SPEED = 7;
    private static final String[] nameList = {"Ghoul", "Zombie", "Unicorn", "Pig", "Eldrich Abomination"};

    /**
      *randomy creates an enemy
      *
      *@param row the horizontal position
      *@param col the vertical position
      *
      *@return an enemy with set position and random stats
      */
    public static Enemy generate(int row, int col) {
        String name = nameList[rng.nextInt(nameList.length)];
        int health = rng.nextInt(50)+50;
        int attack = rng.nextInt(30);
        int protection = rng.nextInt(30);
        int speed = rng.nextInt(ENEMY_MAX_SPEED - 1) + 2;
        return new Enemy(name, row, col, health, attack, protection, speed);
    }
}

