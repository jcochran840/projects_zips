// Position.java
/**
  *represents a simple row/col position in the world
  */
public class Position {
    private int row;
    private int col;

    /**
      *default position constructor
      */
    public Position() {
        row = 0;
        col = 0;
    }

    /**
      *position constructor
      *
      *@param row horizontal position
      *@param col vertical position
      */
    public Position(int row, int col) {
        this.row = row;
        this.col = col;
    }

    @Override
    /**
      *checks the position of an object
      *
      *@return a boolean when they are equal when both coordinates match
      */
    public boolean equals(Object other) {
        Position op = (Position) other;

        return (this.row == op.row && this.col == op.col);
    }

    /**
      *checks 2 positions
      *
      *@return whether a position is adjacent to another (or equal)
      */
    public boolean isAdjacent(Position other) {
        int rowdiff = Math.abs(this.row - other.row);
        int coldiff = Math.abs(this.col - other.col);

        if (rowdiff + coldiff < 2) {
            return true;
        } else {
            return false;
        }
    }

    /**
      *gets the row
      *
      *@return row
      */
    public int getRow() {
        return row;
    }

    /**
      *gets column
      *
      *@return column
      */
    public int getCol() {
        return col;
    }

    /**
      *sets the row
      */
    public void setRow(int row) {
        this.row = row;
    }

    /**
      *sets the column
      */
    public void setCol(int col) {
        this.col = col;
    }
}

