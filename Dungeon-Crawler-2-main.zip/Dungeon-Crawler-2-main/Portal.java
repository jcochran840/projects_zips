import ansi_terminal.*;
/**
  *this class handles the portals and its aspects
  */
public class Portal extends Entity{
    private String name;
    private String target;
    public static final Color PORTAL_COLOR = Color.GREEN;

    /**
      *portal constructor
      *
      *@param row the horizonatal position
      *@param col the vertical position
      *@param name portal name
      *@param target the portats target destination
      */
    public Portal(int row, int col, String name, String target){
        super(row, col, 'p', PORTAL_COLOR);
        this.name = name;
        this.target = target;
    }

    /**
      *gets the portal target
      *
      *@return target of the portal (where the portal leads to)
      */
    public String getTarget() {
        return target;
    }

    /**
      *gets the portal name
      *
      *@return name of portal
      */
    public String getName() {
        return name;
    }
}
