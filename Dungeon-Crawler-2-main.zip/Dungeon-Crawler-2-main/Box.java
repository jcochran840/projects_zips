// Box.java
// represents a pickup-able item

import ansi_terminal.*;
/**
*this class shows items that are able to be picked up
*/
public class Box extends Entity {
    // the Item that is in the box
    private Item item;
    public static final Color BOX_COLOR = Color.MAGENTA;

/**
*adds a box with an item in it
*@param  row
*@param  col
*@param  item
 */
    // add a box with a given item in it
    public Box(int row, int col, Item item) {
        super(row, col, 'i', BOX_COLOR);
        this.item = item;
    }
/**
*returns item in the box
@return item
*/
    // returns item in the box
    public Item getItem() {
        return item;
    }
}


