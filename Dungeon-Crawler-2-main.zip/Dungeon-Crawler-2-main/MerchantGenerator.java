import java.util.Random;
/**
 *this class randomly generates merchant characters using a list of pre-defined traits
 */
public class MerchantGenerator {
    private static final Random rng = new Random();
    private static final String[] nameList = {"Drebin", "Beedle", "Patches", "Rodin", "Happy Mask Salesman"};

    /**
      *merchant constructor, uses rng to choose from pre-defined traits 
      *and automatically fills the merchants inventory with random items
      *
      *@param row the horizontal position
      *@param col the vertical position
      *
      *@return a merchant character with a full inventory
      */
    public static Merchant generate(int row, int col) {
        String name = nameList[rng.nextInt(nameList.length)];
        Inventory wares = new Inventory(999);
        int wareNum = (1+rng.nextInt(7));
        for(int i = 0; i < wareNum; i++){
            Item n = ItemGenerator.generate();
            wares.add(n);
        }
        return new Merchant(name, row, col, wares);
    }
}
