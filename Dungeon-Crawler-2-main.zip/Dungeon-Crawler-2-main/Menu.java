import ansi_terminal.*;
/**
  *this class is responsible for controlling the main menu and its options
  */
public class Menu {

    // game menu options
    private static final String[] gameMenuOptions = {
        "View Inventory",
        "Use Item",
        "Equip Weapon",
        "Equip Armor",
        "Drop",
        "Save",
        "Exit Menu"};

    // main menu options
    private static final String[] mainMenuOptions = {
        "New Game",
        "Load Game",
        "Exit Game"};

    // list of Key enum values where literal strings are unusable
    private static final String[] nonInputs = {
        "AMPERSAND",
        "ASTERISK",
        "AT",
        "BACKQUOTE",
        "BACKSLASH",
        "BACKSPACE",
        "CARET",
        "COLON",
        "COMMA",
        "D0",
        "D1",
        "D2",
        "D3",
        "D4",
        "D5",
        "D6",
        "D7",
        "D8",
        "D9",
        "DOLLAR",
        "DOT",
        "DOWN",
        "ENTER",
        "EQUALS",
        "ESCAPE",
        "EXCLAIM",
        "FORWARDSLASH",
        "GREATER",
        "HASH",
        "LEFT",
        "LEFTBRACE",
        "LEFTBRACKET",
        "LEFTPAREN",
        "LESS",
        "MINUS",
        "NONE",
        "PERCENT",
        "PLUS",
        "QUESTION",
        "QUOTE",
        "QUOTEDBL",
        "RIGHT",
        "RIGHTBRACE",
        "RIGHTBRACKET",
        "RIGHTPAREN",
        "SEMICOLON",
        "SPACE",
        "TAB",
        "TILDE",
        "UNDERSCORE",
        "UP",
        "VERTICALBAR"
    };

    private static final int MAX_INPUT_LENGTH = 10;

    /**
      *prints the options and currently selected item onto the terminal
      *
      *@param row the horozontal position
      *@param col the vertical position
      *@param opt the number for the corresponding option
      *@param menuOptions an ArrayList of the current menu options
      */
    public static void printMenu(int row, int col, int opt, String[] menuOptions) {
        int option = opt;
        int count = 0;

        for (String item: menuOptions) {
            CustomTerminal.warpCursor(row + count, col + 1);
            if (option == count) {
                Terminal.setForeground(Player.PLAYER_COLOR);
                System.out.print("\u20AC " + menuOptions[count] + "          ");
            } else {
                System.out.print("  " + menuOptions[count] + "          ");
            }
            count++;
            Terminal.reset();
        }

    }

    /**
       *prints the game menu
       *
       *@param row the horozontal position
       *@param col the vertical position
       *@param opt the number for the corresponding option   
     */
    public static void printGameMenu(int row, int col, int opt) {
        printMenu(row, col, opt, gameMenuOptions);
    }

    /**
      *prints the main menu
      *
      *@param opt the number of the corresponding menu option
      */
    public static void printMainMenu(int opt) {
        printMenu(23, 53, opt, mainMenuOptions);
    }

    /**
      *controls which option player chooses while in menu;
      *prevents out-of-bounds options
      *
      *@param choice the users choice
      *@param num 
      *
      *@return the corresponding numbers of the player choice
      */
    public static int menuBoundaries(int choice, int num) {
        if (choice < 0) {
            return num;
        }
        if (choice > num) {
            return 0;
        }
        return choice;
    }

    /**
      *gets the game menu options
      *
      *@return the game menu options
      */
    public static String[] getGameMenuOptions() {
        return gameMenuOptions;
    }


    /**
      *gets the main menu options
      *
      *@return the main menu options
      */
    public static String[] getMainMenuOptions() {
        return mainMenuOptions;
    }

    /**
      *player inputs an alphanumeric string of some specified length
      *
      *@param row
      *@param col
      *@param message
      *@param extension
      *
      *@return the user input
      */
    public static String inputName(int row, int col, String message, String extension){

        Key key = null;

        // name of save file
        String result = "";

        while (key != Key.ESCAPE) {
            CustomTerminal.warpCursor(row, col);
            System.out.print(message + result);
            key = Terminal.getKey();
            boolean found = false;

            // checks if the user's input can be converted to a character
            for (String s: nonInputs) {
                if (s.equals(key.name())) {
                    found = true;
                }
            }

            // if the user's input is a character, add it to the save file name
            if (!found) {
                result += key.name();
            }

            // checks for various other inputs
            switch(key) {

                // exits without saving
                case ESCAPE:
                    return "ESCAPE";

                    // return save file name
                case ENTER:
                    return result + extension;

                    // adds space to save file name
                case SPACE:
                    result += " ";
                    break;

                    // adds numbers to save file name
                case D0:
                    result += "0";
                    break;
                case D1:
                    result += "1";
                    break;
                case D2:
                    result += "2";
                    break;
                case D3:
                    result += "3";
                    break;
                case D4:
                    result += "4";
                    break;
                case D5:
                    result += "5";
                    break;
                case D6:
                    result += "6";
                    break;
                case D7:
                    result += "7";
                    break;
                case D8:
                    result += "8";
                    break;
                case D9:
                    result += "9";
                    break;

                    // removes a character from save file name
                case BACKSPACE:
                    if (result.length() > 0){
                        result = result.substring(0,result.length()-1);
                    }
            }

            // restricts player's input to some specific length
            if (result.length() > MAX_INPUT_LENGTH) {
                result = result.substring(0, MAX_INPUT_LENGTH);
            }
        }

        // special case
        return "";
    }
}
