
import java.util.Hashtable;
import ansi_terminal.*;

/** 
  *singleton used to grab contrast colors;
  * ex: the contrast color of red is green
  */
public class ContrastColorReferenceTable{

    private Hashtable<Color,Color> reference;
    private static ContrastColorReferenceTable table;

    // constructor; only constructed if the object does not exist yet
    private ContrastColorReferenceTable() {
        reference = new Hashtable<>();

        // set contrast colors
        reference.put(Color.RED, Color.GREEN);
        reference.put(Color.YELLOW, Color.MAGENTA);
        reference.put(Color.BLUE, Color.MAGENTA);
        reference.put(Color.GREEN, Color.RED);
        reference.put(Color.MAGENTA, Color.YELLOW);
        reference.put(Color.CYAN, Color.MAGENTA);
    }

    /** 
      *returns singleton instance
      */
    public static ContrastColorReferenceTable instance() {
        if (table == null) {
            table = new ContrastColorReferenceTable();
        }
        return table;
    }

    /**
      *grabs contrast color
      *
      *@param color
      *
      *@return the contrast color
      */
    public Color getContrastColor(Color color) {
        if (table == null) {
            return Color.WHITE;
        }
        return reference.get(color);
    }
}
