// Inventory.java
// allows for storing some number of items for the player

import java.util.ArrayList;
import java.util.Scanner;
import ansi_terminal.*;

/**
  *allows for storing some number of items for the player
  */
public class Inventory {
    // the actual list of items
    private ArrayList<Item> items;

    // which item is equipped, if any
    private Item equippedArmor;
    private Item equippedWeapon;

    // the max weight limit for the player here
    private int maxWeight;

   /**
     *the inventory constructor
     *
     *@param maxWeight the inventory weight limit
     */
    public Inventory(int maxWeight) {
        items = new ArrayList<Item>();
        this.maxWeight = maxWeight;
    }

    /**
      *add item to inventory
      *
      *@return true on success, false when full
      */
    public boolean add(Item item) {
        if ((item.getWeight() + totalWeight()) > maxWeight) {
            return false;
        } else {
            items.add(item);
            return true;
        }
    }

    /**
      *this method not only adds the item, but equips it into the correct slot
      *it is used for setting up the player's starting gear
      */
    public void addAndEquip(Item item) {
        items.add(item);

        if (item.getType() == ItemType.Weapon) {
            equippedWeapon = item;
        } else if (item.getType() == ItemType.Armor) {
            equippedArmor = item;
        }
    }

    /**
      *equip an item
      */
    public void equip(Item item) {
        if (item.getType() == ItemType.Weapon) {
            equippedWeapon = item;
        } else if (item.getType() == ItemType.Armor) {
            equippedArmor = item;
        }
    }

    /**
      *get the equipped weapon
      *
      *@return the players equiped weapon
      */
    public Item getEquippedWeapon() {
        return equippedWeapon;
    }

    /**
      *get the equipped armor
      *
      *@return the player's armor
      */
    public Item getEquippedArmor() {
        return equippedArmor;
    }

    /**
      *shows a list of the items in the players inventory
      *
      *@return a list of items in the player's inventory
      */
    public ArrayList<Item> getItems(){
        return items;
    }

    /**
      *shows the max weight for the players inventory
      *
      *@return the player's max weight for their inventory
      */
    public int getMaxWeight() {
        return maxWeight;
    }

    /**
      *show th e total weight of all items in the players inventory
      *
      *@return the total weight of all items stored
      */
    public int totalWeight() {
        int total = 0;
        for (Item i : items) {
            total += i.getWeight();
        }
        return total;
    }

    /**
      *print all of the items in the list, that match the given type (can be null)
      *
      *@param equipmentList the array list of items
      *@param choice the number that corresponds to the place the item holds in the list
      *
      *@return the number of items matching they type
      */
    private int print(ArrayList<Item> equiptmentList, int choice) {
        // clear the terminal so we print over all else
        Terminal.clear();

        // print a heading row
        // the numbers and junk are to make it print in nice columns
        Terminal.setForeground(Color.RED);
        Terminal.warpCursor(1,0);
        System.out.printf("%-4s %-40s %-8s %-8s %-8s\n\r", "No.", "Name", "Weight", "Value", "Strength");
        Terminal.reset();

        // print each item out
        int num = 0;
        for (Item i : equiptmentList) {
            if (num == choice){
                Terminal.setBackground(Player.PLAYER_COLOR);
                Terminal.setForeground(Color.BLACK);
            }

            String displayName = i.getName();

            if (displayName.contains("Potion")) {
                displayName = "\u2665 " + displayName;
            } else if (i.getType().equals(ItemType.Armor)) {
                displayName = "\u26E8 " + displayName;
            } else if (i.getType().equals(ItemType.Weapon)) {
                displayName = "\u25B2 " + displayName;
            }

                System.out.printf("%-4d %-40s %-8s %-8s %-8s", num + 1, displayName, i.getWeight(), i.getValue(), i.getStrength());

            // tell them if this thing is equipped
            if (i == equippedArmor) {
                System.out.print(" (equipped armor)");
            } else if (i == equippedWeapon) {
                System.out.print(" (equipped weapon)");
            }
            System.out.print("\n\r");
            Terminal.reset();

            num++;
        }
        if (num == choice) {
            Terminal.setBackground(Player.PLAYER_COLOR);
            Terminal.setForeground(Color.BLACK);
        }
        if (choice >= 0) {
            System.out.print("ESCAPE");
        }
        Terminal.reset();
        return num;
    }


    /**
      *stay here until the user is ready to go back
      */
    public void pressAnyKey(int row) {
        Terminal.warpCursor(row, 0);
        System.out.printf("\n\rPress any key to return...\n\r");
        Terminal.getKey();
    }

    /**
      *print all of the items in the list
      */
    public void print() {
        print(items, -1);
        pressAnyKey(items.size()+2);
    }

    /**
      *drop an item from the inventory
      *
      *@return what was dropped
      */
    public Item drop() {
        Item toDrop = pickItem(null);
        if (toDrop != null) {
            // if we're dropping our equipped stuff, remove those too!
            if (equippedWeapon == toDrop) {
                equippedWeapon = null;
            } else if (equippedArmor == toDrop) {
                equippedArmor = null;
            }

            items.remove(toDrop);
        }

        if (toDrop != null) {
            System.out.print("You dropped the " + toDrop.getName() + "...\n\r");
        } else {
            System.out.print("You dropped nothing...\n\r");
        }

        pressAnyKey(items.size()+2);
        return toDrop;
    }

    /**
      *equip something
      *
      *@return the item being equipped
      */
    private Item equip(ItemType type) {
        Item thing = pickItem(type);
        if (thing != null) {
            if (thing == equippedWeapon || thing == equippedArmor) {
                System.out.print("You unequipped the " + thing.getName() + "\n\r");
            } else {
                System.out.print("You equipped the " + thing.getName() + "\n\r");
            }
        } else {
            System.out.print("You equipped nothing...\n\r");
        }

        int itemListSize = itemListSize(type);
        pressAnyKey(itemListSize+2);
        return thing;
    }

    /**
      *equip a weapon
      */
    public void equipWeapon() {
        Item select = equip(ItemType.Weapon);
        if (select == equippedWeapon) {
            equippedWeapon = null;
        } else if (select != null) {
            equippedWeapon = select;
        }
    }

    /**
      *equip a piece of armor
      */
    public void equipArmor() {
        Item select = equip(ItemType.Armor);
        if (select == equippedArmor) { 
            equippedArmor = null;
        } else if (select != null) {
            equippedArmor = select;
        }
    }

    /**
      *allows items to be moved from the merchants inventory to the players inventory
      *
      *@param p the player
      *@param m the merchant
      */
    public void buyItem(Player p,Merchant m){
        Item select = pickItem(null);
        if (select != null) {
            // if we're dropping our equipped stuff, remove those too!
            if (p.getGold() >= select.getValue()) {
                if(p.getInventory().add(select) == false){
                    System.out.print("I can't sell it to you if you can't carry it!\n\r");
                } else {
                    System.out.print("Excellent choice!\n\r");
                    p.changeGold(-select.getValue());
                    m.getInventory().getItems().remove(select);
                }
            } else {
                System.out.print("Seems you're a bit short on change, come back when you've got more coin!\n\r");
            }
        }
        pressAnyKey(items.size()+3);
    }

    /**
      *lets the player sell items from their inventory
      *
      *@param p the player
      */
    public void sellItem(Player p){
        Item select = pickItem(null);
        if (select != null) {
            p.changeGold(select.getValue());
            p.getInventory().getItems().remove(select);
            System.out.print("This will make a fine addition to my collection!\n\r");
        }
        pressAnyKey(items.size()+3);
    }

    /**
      *select item to use
      *
      *@return the item to be used
      */
    public Item useItem() {
        Item select = pickItem(ItemType.Other);

        int otherItemListSize = itemListSize(ItemType.Other);
        pressAnyKey(otherItemListSize + 2);
        return select;
    }

    /**
      *gets the size of an item list of a specific type
      *
      *@param type the item type
      *
      *@return the specific item type list size
      */
    private int itemListSize(ItemType type) {
        int result = 0;
        for (Item i : items) {
            if (i.getType() == type) {
                result++;
            }
        }
        return result;
    }

    // creates equiptment list (armor or weapons);
    // used mainly by pickItem() method
    private ArrayList<Item> makeEquiptmentList(ItemType type) {
        ArrayList<Item> result = new ArrayList<>();
        if (type == null) {
            return items;
        }
        for (Item item: items) {
            if (item.getType() == type) {
                result.add(item);
            }
        }
        return result;
    }

    // a method which allows users to choose an item
    // this is private - only called by drop and equip
    private Item pickItem(ItemType filter) {
        // get their choice, only allowing ints in the correct range
        int choice = 0;

        ArrayList<Item> equiptmentList = makeEquiptmentList(filter);
        Key key = Key.G;
        while (key != Key.ESCAPE) {
            // print all the matching items
            int options = print(equiptmentList, choice);
            key = Terminal.getKey();

            switch(key) {

                case UP:
                    choice = Menu.menuBoundaries(choice-1, options);
                    break;
                case DOWN:
                    choice = Menu.menuBoundaries(choice+1, options);
                    break;
                case ENTER:
                    if (choice == options) {
                        return null;
                    } else {
                        return equiptmentList.get(choice);
                    }
                case ESCAPE:
                    return null;

            }
        }
        return null;
    }
}

