import java.util.ArrayList;
/**
  *this class handle the world and its aspects
  */
public class World {
    private ArrayList<Room> rooms;
    private Player player;

    /**
      *World constructer
      *
      *@param rooms arraylist of rooms
      *@param player the player character
      */
    public World(ArrayList<Room> rooms, Player player){
        this.rooms = rooms;
        this.player = player;
    }

    /**
      *default world constructer
      */
    public World() {
        rooms = new ArrayList<>();
        rooms.add(new Room());

        Position startPosition = rooms.get(0).getPlayerStart();
        player = new Player(startPosition, rooms.get(0), "Player", "Default", 100);
    }

    /**
      *gets the arraylist of rooms
      *
      *@return the arraylist of rooms
      */
    public ArrayList<Room> getRooms() {
        return rooms;
    }

   /**
     *gets the player
     *
     *@return the player
     */
    public Player getPlayer() {
        return player;
    }

    /**
      * sets the rooms arraylist
      */
    public void setRooms(ArrayList<Room> rooms) {
        this.rooms = rooms;
    }
}
