import ansi_terminal.*;
import java.io.PrintWriter;
/**
  *this class handles the saving process by writing the game state to a file
  */
public class Save {

    // list of Key enum values where literal strings are unusable
    private static final String[] nonInputs = {
        "AMPERSAND",
        "ASTERISK",
        "AT",
        "BACKQUOTE",
        "BACKSLASH",
        "BACKSPACE",
        "CARET",
        "COLON",
        "COMMA",
        "D0",
        "D1",
        "D2",
        "D3",
        "D4",
        "D5",
        "D6",
        "D7",
        "D8",
        "D9",
        "DOLLAR",
        "DOT",
        "DOWN",
        "ENTER",
        "EQUALS",
        "ESCAPE",
        "EXCLAIM",
        "FORWARDSLASH",
        "GREATER",
        "HASH",
        "LEFT",
        "LEFTBRACE",
        "LEFTBRACKET",
        "LEFTPAREN",
        "LESS",
        "MINUS",
        "NONE",
        "PERCENT",
        "PLUS",
        "QUESTION",
        "QUOTE",
        "QUOTEDBL",
        "RIGHT",
        "RIGHTBRACE",
        "RIGHTBRACKET",
        "RIGHTPAREN",
        "SEMICOLON",
        "SPACE",
        "TAB",
        "TILDE",
        "UNDERSCORE",
        "VERTICALBAR"
    };

    /**
      *saves world data (all instance variables in World object) into a text file
      *
      *@param player the player character
      *@param p the PrintWriter to write to a file
      *@param world the game world
      *@param playerLocation the players current location
      */
    public static void save(Player player, PrintWriter p, World world, Room playerLocation){
        for(Room room: world.getRooms()){
            p.println(room.getName());

            // stores list of enemies for a room
            p.println("List'O'Enemies for " + room.getName() + ":");
            for(Enemy enemy: room.getEnemies()) {
                p.println(enemy.getName());
                p.println(enemy.getRow());
                p.println(enemy.getCol());
                p.println(enemy.getHealth());
                p.println(enemy.getDamage());
                p.println(enemy.getProtection());
                p.println(enemy.getSpeed());
                p.println("%%%");
            }
            p.println("~~~");

            // stores list of items for a room
            p.println("List'O'Boxes for " + room.getName() + ":");
            for(Box box: room.getBoxes()) {
                Item temp = box.getItem();
                p.println(temp.getName());
                p.println(box.getRow());
                p.println(box.getCol());
                p.println(temp.getType());
                p.println(temp.getWeight());
                p.println(temp.getStrength());
                p.println(temp.getValue());
                p.println("%%%");
            }
            p.println("~~~");

            // stores list of portals for a room
            p.println("List'O'Portals for " + room.getName() + ":");
            for (Portal portal: room.getPortals()) {
                p.println(portal.getRow());
                p.println(portal.getCol());
                p.println(portal.getName());
                p.println(portal.getTarget());
                p.println("%%%");
            }

            p.println("~~~");

            // sotres list of merchants for a room
            p.println("List'O'Merchants for " + room.getName() + ":");
                for (Merchant merchant: room.getMerchants()) {
                    p.println(merchant.getName());
                    p.println(merchant.getRow());
                    p.println(merchant.getCol());
                    p.println(merchant.getName() + "'s wares: ");
                    for (Item item : merchant.getInventory().getItems()) {
                        p.println(item.getName());
                        p.println(item.getType());
                        p.println(item.getWeight());
                        p.println(item.getStrength());
                        p.println(item.getValue());
                        p.println("%");
                    }
                    p.println("~~~");
                }
            p.println("~~~");
            p.println("~~~END OF ROOM \"" + room.getName() + "\"");
        }
        // stores player data
        p.println("Player stats: ");
        p.println(player.getName());
        p.println(player.getCode());
        p.println(player.getGold());
        p.println(player.getRow());
        p.println(player.getCol());
        p.println(player.getHealth());
        p.println(playerLocation.getName());

        // stores player's weapon name
        p.println("Player equipped weapon: ");
        Item equipWeapon = player.getInventory().getEquippedWeapon();
        if (equipWeapon != null) {
            p.println(equipWeapon.getName());
        } else {
            p.println("");
        }

        // stores player's armor name
        p.println("Player equipped armor:");
        Item equipArmor = player.getInventory().getEquippedArmor();
        if (equipArmor != null) {
            p.println(equipArmor.getName());
        } else {
            p.println("");
        }

        // stores data on player's inventory
        p.println(player.getName() + "'s inventory: ");
        for (Item item: player.getInventory().getItems()) {
            p.println(item.getName());
            p.println(item.getType());
            p.println(item.getWeight());
            p.println(item.getStrength());
            p.println(item.getValue());
            p.println("%");
        }     
    }
}
