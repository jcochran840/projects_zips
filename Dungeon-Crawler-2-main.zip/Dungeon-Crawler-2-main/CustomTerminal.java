
import ansi_terminal.*;
/**
  *this class is used to adjust the assets positions vertically or horizontally
  */
public class CustomTerminal{

    private static final int VERTICAL_OFFSET = 10;
    private static final int HORIZONTAL_OFFSET = 15;

    /**
      *used to shift game assets vertically and/or horizontally
      */
    public static void warpCursor(int row, int col) {
        Terminal.warpCursor(row + VERTICAL_OFFSET, col + HORIZONTAL_OFFSET);
    }

}
