
import ansi_terminal.*;
import java.util.ArrayList;
import java.util.Scanner;
/**
  *this class is used to store the frames and display them on screen 
  */
public class Animation {

    private ArrayList<ArrayList<String>> frames;
    private Position position;

    public Animation() {}
/**
  *reads in frames and assigns them a position
  */
    public Animation(Scanner in, String fileName, int row, int col) {

        position = new Position(row, col);

        try {
            frames = AnimationRenderer.load(in);
        } catch (Exception e) {
            System.out.print("Cannot load \"" + fileName + "\"");
            Terminal.pause(3);
        }
    }
/**
  *places the frames in the assigned position
  */
    public void playAnimation() {
        if (frames != null) {
            AnimationRenderer.printAnimation(frames, position.getRow(), position.getCol());
        }
    }
/**
  *reads frames stored in arraylist
  *
  *@throws  exception if no frame in found at the called position
  */
    public ArrayList<String> getFrame (int num) throws Exception {
        if (frames != null){
            if (num >= 0 && num < frames.size()) {
                return frames.get(num);
            } else {
            Terminal.clear();
            Terminal.reset();
            Terminal.cookedMode();
            throw new Exception("Cannot grab frame" + num + "!");
            }
        } else {
            throw new Exception("Frames do not exist!");
        }
    }

    public int size() {
        return frames.size();
    }
}
