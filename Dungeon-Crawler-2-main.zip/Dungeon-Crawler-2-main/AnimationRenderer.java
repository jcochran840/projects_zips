import java.util.ArrayList;
import java.util.Scanner;
import ansi_terminal.*;
/**
  *this class renders the frames of animations
  */
public class AnimationRenderer {

    private static final double FRAME_WAIT_RATE = 0.1;

    /**
      *reads in the frames from a file
      *
      *@param in a scanner to read the file
      *
      *@return all frames in the form of an ArrayList
      */
    public static ArrayList<ArrayList<String>> load(Scanner in) {

        ArrayList<ArrayList<String>> frames = new ArrayList<>();
        ArrayList<String> tempFrame = new ArrayList<>();
        String tempLine;

        // reads the whole file
        while(in.hasNextLine()) {
            tempLine = in.nextLine();

            // checks if a new line of the frame needs to be added
            if(!tempLine.equals("END OF FRAME")) {

                // adds another line of the frame
                tempFrame.add(tempLine);
            } else {

                // when "Next Frame" line is reached, the new frame is added to
                // the list of frames
                frames.add(tempFrame);
                tempFrame = new ArrayList<>();
            }
        }

        // returns all frames of the animation
        return frames;
    }

    /**
      *prints frames from an .frames file and prints at a specific row and col on the terminal
      */
    public static void printAnimation(ArrayList<ArrayList<String>> frames, int row, int col) {

        int currentRow = row;

        // prints all the frames in the frame list
        for (ArrayList<String> frame: frames){
            currentRow = row;

            // prints each line in a frame
            for (String line: frame) {
                Terminal.warpCursor(currentRow,col);
                System.out.print(line);
                currentRow++;
            }
            Terminal.pause(FRAME_WAIT_RATE);
        }
    }

    /** 
      *prints an image in a specified row and column on the terminal
      */
    public static void printSprite(ArrayList<String> sprite, int row, int col) {

        // prints the image line-by-line
        for (String line: sprite) {
            Terminal.warpCursor(row, col);
            System.out.print(line);
            row++;
        }
    }
}
